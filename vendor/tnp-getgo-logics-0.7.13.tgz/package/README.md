# @tnp/getgo-logics

Shared GetGo domain, application, and Firebase data-access logic for the web
and Expo/React Native clients.

## Boundary

This package does not initialize Firebase or access React, React Native, Expo,
the DOM, `localStorage`, or `AsyncStorage`. Each client owns platform bootstrap
and injects initialized Firebase instances and persistence adapters.

## Development

```bash
npm install
npm run check
```

## Entry points

- `@tnp/getgo-logics` — domain, use cases, and platform ports
- `@tnp/getgo-logics/domain` — canonical models
- `@tnp/getgo-logics/firebase` — injected Firebase auth and GetGo repositories
- `@tnp/getgo-logics/authoring` — dynamic-question and quiz-source workflows
- `@tnp/getgo-logics/runtime` — dynamic quiz evaluation and regeneration
- `@tnp/getgo-logics/quiz-builder` — QuizBuilder, localization/math helpers,
  value serialization, and LINQ helpers
- `@tnp/getgo-logics/testing` — test adapters

## Shared workflows

- Authentication: email/password, guest, verification, reset, and sign-out
- OAuth account-profile linking and merge rules (clients own popup/native UI)
- Parent/student profiles, learner visibility, quiz ordering, and leaderboards
- Parent subscription administration and AI usage dashboards
- Contest/quiz catalog, practice, and dynamic-module selection
- Question reporting and Firebase question-subcollection persistence
- Firebase Storage quiz assets and callable dynamic-question conversion
- Test creation, persistence, grading, exercise rewards, and exam completion
- Quiz progression, weak-question analysis, and progress resets
- Daily/weekly tracking calculations and Firebase persistence
- Learning selection, profile preferences, guest sessions, and dashboards

Clients retain Firebase initialization, React/navigation state, browser/native
storage adapters, OAuth UI, and DOM/device lifecycle code. Quiz authoring,
QuizBuilder, and runtime rules are owned by this package; clients inject only
platform capabilities such as hashing, storage, loading, and editor UI.
Permanent contest, quiz, question-subcollection, and Storage deletion is
available through explicitly named destructive methods. Every client must keep
those methods behind its administrator authorization boundary.
