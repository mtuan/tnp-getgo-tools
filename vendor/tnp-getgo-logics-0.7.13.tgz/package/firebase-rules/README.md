# GetGo Firebase rules

This directory is the authoritative source for GetGo Firestore and Cloud Storage rules used by Web, App, and Tools.

- Edit rule fragments under `shared/` and `apps/`.
- Run `npm run generate:firebase-rules` after changing a fragment.
- Deploy only the files under `generated/`.
- `npm run check:firebase-rules` fails when generated files are stale.

Content publishing uses the `contentPublisher` Firebase Auth custom claim in both Firestore and Storage. The legacy `contentAdmin` claim and bootstrap publisher emails remain temporarily supported for existing administrative accounts. Firestore can additionally recognize the shared whitelist and stored admin groups; Storage rules cannot query Firestore.

`tnp-getgo-web` copies the generated rules from the installed `@tnp/getgo-logics` package into its target deployment bundle. `tnp-getgo-app` references the same generated files and does not maintain a separate ruleset.
