# GetGo Firebase rules

This directory is the authoritative source for GetGo Firestore and Cloud Storage rules used by Web, App, and Tools.

- Edit rule fragments under `shared/` and `apps/`.
- Keep compatibility for installed legacy clients under `apps/getgo/legacy/`.
  These fragments may be removed only after those client versions are retired.
- Run `npm run generate:firebase-rules` after changing a fragment.
- Deploy only the files under `generated/`.
- `npm run check:firebase-rules` fails when generated files are stale.
- `npm run test:firebase-rules` compiles both generated rulesets and exercises
  the installed legacy client's access contract against local emulators without
  contacting a real Firebase project.

Content publishing uses the `contentPublisher` Firebase Auth custom claim in both Firestore and Storage. The legacy `contentAdmin` claim and bootstrap publisher emails remain temporarily supported for existing administrative accounts. Firestore can additionally recognize the shared whitelist and stored admin groups; Storage rules cannot query Firestore.

`tnp-getgo-web` copies the generated rules from the installed `@tnp/getgo-logics` package into its target deployment bundle. `tnp-getgo-app` references the same generated files and does not maintain a separate ruleset.
