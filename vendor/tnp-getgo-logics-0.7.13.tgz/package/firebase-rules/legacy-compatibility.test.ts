import { readFile } from 'node:fs/promises'
import test from 'node:test'
import {
  assertFails,
  assertSucceeds,
  initializeTestEnvironment,
} from '@firebase/rules-unit-testing'
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore'
import { getBytes, ref, uploadBytes } from 'firebase/storage'

const hasEmulators = Boolean(
  process.env.FIRESTORE_EMULATOR_HOST && process.env.FIREBASE_STORAGE_EMULATOR_HOST,
)

test('legacy client remains usable without gaining billing or publisher access', {
  skip: !hasEmulators,
}, async () => {
  const environment = await initializeTestEnvironment({
    projectId: 'demo-getgo-rules',
    firestore: {
      rules: await readFile(new URL('./generated/firestore.rules', import.meta.url), 'utf8'),
    },
    storage: {
      rules: await readFile(new URL('./generated/storage.rules', import.meta.url), 'utf8'),
    },
  })

  try {
    await environment.withSecurityRulesDisabled(async context => {
      await setDoc(doc(context.firestore(), 'getgo-contests', 'ikmc'), { name: 'IKMC' })
      await setDoc(doc(context.firestore(), 'getgo-support-threads', 'owned-thread'), {
        userId: 'legacy-user',
        status: 'open',
        createdAt: new Date(),
      })
      await uploadBytes(ref(context.storage(), 'getgo-quizzes/ikmc/raw.json'), new Uint8Array([1]))
      await uploadBytes(ref(context.storage(), 'getgo-sources/ikmc/source.js'), new Uint8Array([2]))
    })

    const legacy = environment.authenticatedContext('legacy-user')
    const other = environment.authenticatedContext('other-user')
    const legacyDb = legacy.firestore()

    await assertSucceeds(getDoc(doc(legacyDb, 'getgo-contests', 'ikmc')))
    await assertSucceeds(setDoc(doc(legacyDb, 'getgo', 'legacy-user'), {
      id: 'legacy-user',
      name: 'Legacy Parent',
      email: 'legacy@example.com',
    }))
    await assertSucceeds(setDoc(doc(legacyDb, 'getgo', 'legacy-user', 'students', 'student-1'), {
      id: 'student-1',
      parentId: 'legacy-user',
    }))
    await assertFails(setDoc(doc(legacyDb, 'getgo', 'another-legacy-user'), {
      packageId: 'premium',
    }))
    await assertFails(updateDoc(doc(legacyDb, 'getgo', 'legacy-user'), {
      packageId: 'premium',
    }))
    await assertSucceeds(getDoc(doc(legacyDb, 'getgo-support-threads', 'owned-thread')))
    await assertFails(getDoc(doc(other.firestore(), 'getgo-support-threads', 'owned-thread')))

    await assertSucceeds(getBytes(ref(legacy.storage(), 'getgo-quizzes/ikmc/raw.json')))
    await assertSucceeds(getBytes(ref(legacy.storage(), 'getgo-sources/ikmc/source.js')))
    await assertFails(uploadBytes(
      ref(legacy.storage(), 'getgo-quizzes/ikmc/forged.json'),
      new Uint8Array([3]),
    ))
    await assertSucceeds(uploadBytes(
      ref(legacy.storage(), 'getgo-support/legacy-user/owned-thread/image.jpg'),
      new Uint8Array([4]),
      { contentType: 'image/jpeg' },
    ))
    await assertFails(uploadBytes(
      ref(other.storage(), 'getgo-support/legacy-user/owned-thread/other.jpg'),
      new Uint8Array([5]),
      { contentType: 'image/jpeg' },
    ))
  } finally {
    await environment.cleanup()
  }
})
