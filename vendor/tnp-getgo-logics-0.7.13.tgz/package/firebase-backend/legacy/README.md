# Legacy Firebase sources

These sources are preserved for historical compatibility but are not included in the active GetGo deployment target.

`users` previously lived under GetGo Web. Its `findAccountByEmail` Function and email index are inactive; moving them here preserves the implementation without presenting Web as their canonical owner.
