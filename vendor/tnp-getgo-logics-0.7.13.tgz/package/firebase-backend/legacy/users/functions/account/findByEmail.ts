import { onCall, HttpsError } from 'firebase-functions/v2/https'
import { getFirestore } from 'firebase-admin/firestore'
import type { AuthUser } from '@tnp/shared'
import { callableError, withCallableErrorDetails } from '../../callableError.js'

interface FindByEmailInput {
  email: string
}

interface FindByEmailOutput {
  uid: string
  name: string
  email: string
  linkedProviders: string[]
  createdAt: number
}

export const findAccountByEmail = onCall<FindByEmailInput, Promise<FindByEmailOutput | null>>(
  { region: 'asia-southeast1' },
  withCallableErrorDetails('Account lookup failed', async (request) => {
    if (!request.auth) {
      throw new HttpsError('unauthenticated', 'Must be signed in')
    }

    const { email } = request.data
    if (!email || typeof email !== 'string') {
      throw new HttpsError('invalid-argument', 'Valid email required')
    }

    try {
      const db = getFirestore()
      const query = await db
        .collection('users')
        .where('email', '==', email)
        .limit(1)
        .get()

      if (query.empty) {
        return null
      }

      const doc = query.docs[0]
      const data = doc.data() as AuthUser

      return {
        uid: doc.id,
        name: data.name,
        email: data.email,
        linkedProviders: Object.keys(data.linkedProviders || {}),
        createdAt: data.createdAt?.getTime() || 0,
      }
    } catch (err) {
      console.error('Error finding account:', err)
      throw callableError('internal', 'Failed to find account', err)
    }
  })
)
