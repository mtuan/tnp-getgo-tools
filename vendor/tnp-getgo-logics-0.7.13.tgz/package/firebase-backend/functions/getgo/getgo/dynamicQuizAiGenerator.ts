import {OpenAI} from "openai";
import {zodTextFormat} from "openai/helpers/zod";
import {z} from "zod";
import {
  dynamicQuestionProposalSchema,
} from "./dynamicQuestionProposal.js";
import {
  partitionDynamicQuizQuestions,
  type DynamicQuizQuestionProposal,
} from "./dynamicQuizLocalNormalizer.js";
import {
  buildDynamicQuizRequestPayload,
  DYNAMIC_QUIZ_CACHED_SYSTEM_PROMPT,
  DYNAMIC_QUIZ_PROMPT_CACHE_KEY,
} from "./dynamicQuizAiRequest.js";

const dynamicQuizProposalSchema = z.object({
  proposals: z.array(z.object({
    questionIndex: z.number().int().min(0),
    questionNo: z.number(),
    proposal: dynamicQuestionProposalSchema,
  })).min(1),
});

interface GenerateDynamicQuizProposalOptions {
  client: OpenAI;
  model: string;
  quiz: Record<string, unknown>;
  instructions?: string;
  currentDate?: string;
}

export interface DynamicQuizProposalItem {
  questionIndex: number;
  questionNo: number;
  generationMode?: "ai" | "local-image";
  proposal: DynamicQuizQuestionProposal;
}

export async function generateDynamicQuizProposal({
  client,
  model,
  quiz,
  instructions,
  currentDate = new Date().toISOString(),
}: GenerateDynamicQuizProposalOptions) {
  const questions = Array.isArray(quiz.questions) ?
    quiz.questions as Record<string, unknown>[] :
    [];
  const {aiQuestions, localItems} =
    partitionDynamicQuizQuestions(questions);
  const aiQuiz = {
    ...quiz,
    questions: aiQuestions.map(({question}) => question),
  };
  const requestPayload = buildDynamicQuizRequestPayload({
    quiz: aiQuiz,
    instructions,
    currentDate,
  });

  if (aiQuestions.length === 0) {
    return {
      proposals: localItems,
      model,
      request: requestPayload,
      responseId: "local-image-normalization",
      usage: {
        inputTokens: 0,
        outputTokens: 0,
        totalTokens: 0,
        cachedInputTokens: 0,
        cacheWriteTokens: 0,
      },
      rawUsage: undefined,
    };
  }

  const response = await client.responses.parse({
    model,
    reasoning: {effort: "medium"},
    input: [
      {
        role: "system",
        content: [{
          type: "input_text",
          text: DYNAMIC_QUIZ_CACHED_SYSTEM_PROMPT,
          prompt_cache_breakpoint: {mode: "explicit"},
        }],
      },
      {
        role: "user",
        content: [{
          type: "input_text",
          text: JSON.stringify(requestPayload),
        }],
      },
    ],
    text: {
      format: zodTextFormat(
        dynamicQuizProposalSchema,
        "getgo_dynamic_quiz_proposals"
      ),
      verbosity: "low",
    },
    prompt_cache_key: DYNAMIC_QUIZ_PROMPT_CACHE_KEY,
    prompt_cache_options: {
      mode: "explicit",
      ttl: "30m",
    },
  });

  if (!response.output_parsed) {
    throw new Error("OpenAI returned no structured batch proposal.");
  }

  if (response.output_parsed.proposals.length !== aiQuestions.length) {
    throw new Error(
      `Expected ${aiQuestions.length} AI proposals, received ` +
      `${response.output_parsed.proposals.length}.`
    );
  }
  const seenIndexes = new Set<number>();
  const aiItems = response.output_parsed.proposals.map((item) => {
    const source = aiQuestions[item.questionIndex];
    if (!source || seenIndexes.has(item.questionIndex)) {
      throw new Error(
        `AI returned an invalid filtered question index ${item.questionIndex}.`
      );
    }
    seenIndexes.add(item.questionIndex);
    const questionNo = Number(source.question.question_no);
    if (item.questionNo !== questionNo) {
      throw new Error(
        `AI returned question ${item.questionNo} for filtered index ` +
        `${item.questionIndex}; expected ${questionNo}.`
      );
    }
    return {
      ...item,
      questionIndex: source.questionIndex,
      questionNo,
      generationMode: "ai" as const,
    };
  });
  const proposals = [...localItems, ...aiItems]
    .sort((left, right) => left.questionIndex - right.questionIndex);

  return {
    proposals,
    model,
    request: requestPayload,
    responseId: response.id,
    usage: {
      inputTokens: response.usage?.input_tokens ?? 0,
      outputTokens: response.usage?.output_tokens ?? 0,
      totalTokens: response.usage?.total_tokens ?? 0,
      cachedInputTokens:
        response.usage?.input_tokens_details?.cached_tokens ?? 0,
      cacheWriteTokens:
        response.usage?.input_tokens_details?.cache_write_tokens ?? 0,
    },
    rawUsage: response.usage,
  };
}
