import {z} from "zod";
import type {
  GetGoDynamicQuestionProposal,
  GetGoDynamicQuestionProposalResult,
} from "@tnp/getgo-logics/authoring";

export const dynamicQuestionProposalSchema = z.object({
  paramsGeneratorTs: z.string().min(1).describe(
    "Only a zero-argument arrow-function expression with a block body, " +
    "for example `() => { const answer = QB.answer.choice(correct, options); " +
    "return { value, answer } }`. " +
    "Never include QB.template(...), another callback, an origin object, " +
    "Markdown fences, labels, explanations, or assistant/system text."
  ),
  questionGeneratorTs: z.string().min(1).describe(
    "Only the question-generator arrow-function expression with a " +
    "destructured parameter and block body, for example " +
    "`({ value, answer }) => { return { ..., answer } }`. Never include " +
    "QB.template(...), the params callback, an origin object, Markdown " +
    "fences, labels, explanations, or assistant/system text."
  ),
  originParamsTs: z.string().min(1).describe(
    "Only a plain object expression that reproduces the original question, " +
    "for example `{ value: 12, answer: QB.answer.choice('B', " +
    "[12, 24, 36]) }`. " +
    "Never include QB.template(...), any callback, Markdown fences, labels, " +
    "explanations, or assistant/system text."
  ),
  explanationGeneratorTs: z.string().min(1).describe(
    "Only an explanation-generator arrow function with the same destructured " +
    "params as questionGeneratorTs and a block body. It must return " +
    "`{ en: string, vi?: string }` explaining how to solve the generated " +
    "question. Never include QB.template(...), Markdown fences, labels, or " +
    "assistant/system text."
  ),
  parameterizedValues: z.array(z.object({
    original: z.string(),
    parameter: z.string(),
    reason: z.string(),
  })),
  explanation: z.string().min(10),
  assumptions: z.array(z.string()),
  warnings: z.array(z.string()),
  confidence: z.number().min(0).max(1),
});

export type DynamicQuestionProposal = GetGoDynamicQuestionProposal;

export interface DynamicQuestionProposalRequest {
  contestId: string;
  quizId: string;
  questionId: string;
  instructions?: string;
}

export type DynamicQuestionProposalResult =
  GetGoDynamicQuestionProposalResult;
