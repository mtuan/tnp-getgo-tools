import {
  GENERAL_CONVERSION_REQUEST,
  QUIZ_BUILDER_AI_PROMPT_CACHE_KEY,
  QUIZ_BUILDER_AI_SYSTEM_PROMPT,
} from "@tnp/getgo-logics/authoring";

interface DynamicQuizRequestOptions {
  quiz: Record<string, unknown>;
  instructions?: string;
  currentDate?: string;
}

const DYNAMIC_QUIZ_BATCH_INSTRUCTIONS = [
  "BATCH OUTPUT CONTRACT",
  "Return exactly one proposal for every input question.",
  "Keep proposals in input order.",
  "questionIndex is the zero-based input-array index.",
  "questionNo must equal the source question_no.",
  "Apply the complete single-question contract independently to every item.",
  "Do not omit difficult questions and do not merge questions.",
  "The application removes image-dependent questions before this request.",
  "Every supplied question is text-only and must be analyzed for useful",
  "constraint-safe parameterization.",
  "For every safely replaceable fictional person, generate a distinct name",
  "parameter and interpolate every occurrence. Never use the person's name as",
  "the variable for a numeric quantity; use lisaName and lisaMarbles, not lisa",
  "for Lisa's marble count. Before returning, scan for hard-coded source names.",
  "Parameterize safe incidental refresh details even when they do not affect",
  "the answer, including nonessential day/month, names, colors, and story",
  "context. Preserve all semantic constraints, return and render each value,",
  "and reproduce the exact original detail in originParamsTs.",
  "Mathematical difficulty is never a reason to keep a text-only quantitative",
  "question fixed. Questions with multiple changeable numbers are presumed",
  "dynamic: derive their invariant and generate constraint-safe seed values.",
  "For worst-case, certainty, pigeonhole, and extremal questions, calculate",
  "the largest avoiding state and add one. For coupled integer systems, derive",
  "displayed totals from valid seeds instead of randomizing totals directly.",
  "Detect written number words as numeric values, not fixed prose. Render a",
  "dynamic count with QB.en.number and use",
  "QB.en.number(count, { capitalize: true }) at sentence start. When the",
  "count controls names, clues, or repeated structures, generate all dependent",
  "content consistently instead of varying the displayed count alone.",
  "Use the locale helpers' { capitalize: true } option for sentence-initial",
  "number words, colors, and animals. Animal categories are house/pet, farm,",
  "wild, sea, and insect; select a context-appropriate category.",
  "Shared quiz context may inform conventions, but each proposal must preserve",
  "its own question logic, original values, choices, and ordering.",
  "First inspect quiz title, year, grade, round, and exam number for semantic",
  "clues. Apply those clues independently when identifying each parameter.",
  "In particular, a four-digit value matching the quiz year is strong evidence",
  "for a calendar-year parameter when varying it preserves the question logic.",
].join("\n");

/**
 * This cached prefix is deliberately constructed at module load time. Never
 * add quiz-, question-, date-, locale-, or administrator-specific data here.
 * Put request-specific values in the user payload built below instead.
 */
export const DYNAMIC_QUIZ_CACHED_SYSTEM_PROMPT =
  `${QUIZ_BUILDER_AI_SYSTEM_PROMPT}\n\n${DYNAMIC_QUIZ_BATCH_INSTRUCTIONS}`;

export const DYNAMIC_QUIZ_PROMPT_CACHE_KEY =
  `${QUIZ_BUILDER_AI_PROMPT_CACHE_KEY}-batch-v8`;

export function buildDynamicQuizRequestPayload({
  quiz,
  instructions,
  currentDate = new Date().toISOString(),
}: DynamicQuizRequestOptions) {
  const questions = Array.isArray(quiz.questions) ? quiz.questions : [];
  return {
    task: "Generate one dynamic QB proposal for every question in this quiz.",
    currentDate,
    quiz: {
      ...quiz,
      questions,
    },
    administratorInstructions:
      instructions?.trim() || GENERAL_CONVERSION_REQUEST,
  };
}
