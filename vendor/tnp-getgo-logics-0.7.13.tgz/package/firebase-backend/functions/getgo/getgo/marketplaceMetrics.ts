import {FieldValue, getFirestore} from "firebase-admin/firestore";
import {onDocumentCreated, onDocumentWritten} from "firebase-functions/v2/firestore";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";

const marketplaceTopic = (topicId: string) =>
  getFirestore().doc(`getgo-marketplace-topics/${topicId}`);

export const trackGetGoParentTopic = onDocumentCreated(
  {
    document: "getgo/{parentId}/topics/{topicId}",
    region: DEPLOYMENT_REGION,
  },
  async (event) => {
    const {parentId, topicId} = event.params;
    const summary = marketplaceTopic(topicId);
    const marker = summary.collection("users").doc(parentId);
    await getFirestore().runTransaction(async (transaction) => {
      const [current] = await transaction.getAll(marker);
      if (current.exists) return;
      transaction.set(marker, {parentId, topicId, addedAt: FieldValue.serverTimestamp()});
      transaction.set(summary, {
        topicId,
        userCount: FieldValue.increment(1),
        updatedAt: FieldValue.serverTimestamp(),
      }, {merge: true});
    });
  },
);

export const aggregateGetGoTopicReview = onDocumentWritten(
  {
    document: "getgo-marketplace-topics/{topicId}/reviews/{parentId}",
    region: DEPLOYMENT_REGION,
  },
  async (event) => {
    const before = event.data?.before.exists ? event.data.before.data() : undefined;
    const after = event.data?.after.exists ? event.data.after.data() : undefined;
    const beforeRating = typeof before?.rating === "number" ? before.rating : 0;
    const afterRating = typeof after?.rating === "number" ? after.rating : 0;
    const countDelta = (after ? 1 : 0) - (before ? 1 : 0);
    const ratingDelta = afterRating - beforeRating;
    if (countDelta === 0 && ratingDelta === 0) return;
    await marketplaceTopic(event.params.topicId).set({
      topicId: event.params.topicId,
      ratingCount: FieldValue.increment(countDelta),
      ratingTotal: FieldValue.increment(ratingDelta),
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
  },
);
