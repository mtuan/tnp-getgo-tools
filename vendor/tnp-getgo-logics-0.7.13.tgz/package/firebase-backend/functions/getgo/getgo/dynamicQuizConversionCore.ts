import type {DynamicQuizProposalItem} from "./dynamicQuizAiGenerator.js";

const INLINE_IMAGE_PATTERN =
  /^data:image\/([a-z0-9.+-]+);base64,([a-z0-9+/=\s]+)$/i;

export interface InlineQuizImage {
  base64: string;
  fileName: string;
  mimeSubtype: string;
  reference: string;
}

export interface ProcessedQuizImages {
  quiz: Record<string, unknown>;
  assetCount: number;
}

export type StoreInlineQuizImage =
  (image: InlineQuizImage) => Promise<void>;

function imageExtension(subtype: string): string {
  const normalized = subtype.toLowerCase();
  if (normalized === "jpeg") return "jpg";
  if (normalized === "svg+xml") return "svg";
  return normalized.replace(/[^a-z0-9]/g, "") || "png";
}

function questionStem(
  question: Record<string, unknown>,
  index: number
): string {
  const questionNo = question.question_no ?? index + 1;
  return `question-${String(questionNo).replace(/[^a-z0-9_-]/gi, "-")}`;
}

export async function preprocessDynamicQuizImages(
  quiz: Record<string, unknown>,
  store: StoreInlineQuizImage
): Promise<ProcessedQuizImages> {
  const questions = Array.isArray(quiz.questions) ? quiz.questions : [];
  let assetCount = 0;
  const processValue = async (
    value: unknown,
    stem: string
  ): Promise<unknown> => {
    if (typeof value !== "string") return value;
    const match = value.match(INLINE_IMAGE_PATTERN);
    if (!match) return value;
    const fileName = `${stem}.${imageExtension(match[1])}`;
    const reference = `asset:${fileName}`;
    await store({
      base64: match[2].replace(/\s/g, ""),
      fileName,
      mimeSubtype: match[1],
      reference,
    });
    assetCount += 1;
    return reference;
  };
  const processedQuestions = await Promise.all(questions.map(
    async (rawQuestion, index) => {
      if (!rawQuestion || typeof rawQuestion !== "object") return rawQuestion;
      const question = rawQuestion as Record<string, unknown>;
      const stem = questionStem(question, index);
      const imageDatas = Array.isArray(question.image_datas) ?
        await Promise.all(question.image_datas.map((image, imageIndex) =>
          processValue(
            image,
            imageIndex === 0 ? stem : `${stem}-${imageIndex + 1}`
          )
        )) :
        question.image_datas;
      const answer =
        question.answer && typeof question.answer === "object" ?
          question.answer as Record<string, unknown> :
          undefined;
      const choices =
        answer?.choices && typeof answer.choices === "object" ?
          answer.choices as Record<string, unknown> :
          undefined;
      const processedChoices = choices ? Object.fromEntries(
        await Promise.all(Object.entries(choices).map(async ([label, value]) => [
          label,
          await processValue(value, `${stem}-${label}`),
        ]))
      ) : undefined;
      return {
        ...question,
        ...(imageDatas !== undefined ? {image_datas: imageDatas} : {}),
        ...(answer ? {
          answer: {
            ...answer,
            ...(processedChoices ? {choices: processedChoices} : {}),
          },
        } : {}),
      };
    }
  ));
  return {
    quiz: {...quiz, questions: processedQuestions},
    assetCount,
  };
}

export function assertDynamicQuizProposalAlignment(
  questions: Record<string, unknown>[],
  proposals: DynamicQuizProposalItem[]
): void {
  if (proposals.length !== questions.length) {
    throw new Error(
      `Expected ${questions.length} proposals, received ${proposals.length}.`
    );
  }
  proposals.forEach((item, index) => {
    const questionNo = Number(questions[index]?.question_no);
    if (item.questionIndex !== index || item.questionNo !== questionNo) {
      throw new Error(
        `Proposal ${index} identifies question ${item.questionNo} at index ` +
        `${item.questionIndex}; expected question ${questionNo} at index ${index}.`
      );
    }
  });
}
