import {getApp} from "firebase-admin/app";
import {getAuth} from "firebase-admin/auth";
import {FieldValue, Timestamp, getFirestore} from "firebase-admin/firestore";
import * as logger from "firebase-functions/logger";
import {HttpsError, onCall, type CallableRequest} from "firebase-functions/v2/https";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";
import {isAdminUser} from "../users/adminAuth.js";

type TestScenario = "matched-topics" | "manual-topics";
type TestAccountRequest = {action?: "suggest" | "create"; email?: string; password?: string; scenario?: TestScenario};

const TEST_EMAIL = /^test([1-9]\d*)@tnp\.com\.vn$/;
const DEVELOPMENT_PROJECT = "tnp-getgo-dev";

async function requireTestAdmin(request: CallableRequest<unknown>): Promise<string> {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  if (!(await isAdminUser(request.auth.uid, typeof request.auth.token.email === "string" ? request.auth.token.email : undefined))) {
    throw new HttpsError("permission-denied", "Admin access required.");
  }
  const projectId = getApp().options.projectId;
  if (!projectId) throw new HttpsError("failed-precondition", "The Firebase project is not configured.");
  if (projectId !== DEVELOPMENT_PROJECT) {
    throw new HttpsError("failed-precondition", "Upgrade test accounts can only be created in development.");
  }
  return projectId;
}

async function emailExists(email: string): Promise<boolean> {
  try {
    await getAuth().getUserByEmail(email);
    return true;
  } catch (error) {
    if ((error as {code?: string}).code === "auth/user-not-found") return false;
    throw error;
  }
}

async function nextTestEmail(): Promise<string> {
  for (let number = 1; number <= 9999; number += 1) {
    const email = `test${number}@tnp.com.vn`;
    if (!(await emailExists(email))) return email;
  }
  throw new HttpsError("resource-exhausted", "No available test email was found.");
}

function validEmail(value: unknown): string {
  const email = typeof value === "string" ? value.trim().toLocaleLowerCase() : "";
  if (!TEST_EMAIL.test(email)) throw new HttpsError("invalid-argument", "Use an email like test1@tnp.com.vn.");
  return email;
}

function validPassword(value: unknown): string {
  if (typeof value !== "string" || value.length < 8 || value.length > 128) {
    throw new HttpsError("invalid-argument", "The test password must contain 8 to 128 characters.");
  }
  return value;
}

async function createTestAccount(request: CallableRequest<TestAccountRequest>) {
  const email = validEmail(request.data?.email);
  const password = validPassword(request.data?.password);
  const scenario: TestScenario = request.data?.scenario === "manual-topics" ? "manual-topics" : "matched-topics";
  if (await emailExists(email)) throw new HttpsError("already-exists", "This test email already exists.");

  const number = Number(TEST_EMAIL.exec(email)?.[1] ?? 1);
  const displayName = `Upgrade Test Parent ${number}`;
  const learnerId = `legacy-student-${number}`;
  const now = Timestamp.now();
  const oldDate = Timestamp.fromMillis(now.toMillis() - 90 * 24 * 60 * 60 * 1000);
  const authUser = await getAuth().createUser({email, password, emailVerified: true, displayName});
  try {
    const firestore = getFirestore();
    const batch = firestore.batch();
    batch.create(firestore.doc(`users/${authUser.uid}`), {
      id: authUser.uid,
      name: displayName,
      email,
      status: "active",
      groups: [],
      appRoles: {},
      registeredFrom: "getgo",
      createdAt: oldDate,
      lastLogin: oldDate,
    });
    batch.create(firestore.doc(`getgo/${authUser.uid}`), {
      id: authUser.uid,
      name: displayName,
      email,
      avatar: "👨‍👩‍👧",
      packageId: "free",
      createdAt: oldDate,
      updatedAt: oldDate,
    });
    const legacyTopics = scenario === "matched-topics" ? ["ikmc", "timo"] : ["legacy-contest-without-current-match"];
    batch.create(firestore.doc(`getgo/${authUser.uid}/students/${learnerId}`), {
      id: learnerId,
      parentId: authUser.uid,
      name: `Legacy Learner ${number}`,
      grade: "grade_5",
      activeTopic: legacyTopics[0],
      enabledTopics: legacyTopics,
      contestGrades: Object.fromEntries(legacyTopics.map((topic) => [topic, "grade_5"])),
      xp: 420,
      level: 4,
      streak: 6,
      createdAt: oldDate,
      updatedAt: oldDate,
    });
    batch.create(firestore.collection("getgo-admin-audit").doc(), {
      action: "upgrade-test-account-created",
      memberId: authUser.uid,
      memberEmail: email,
      scenario,
      changedByUid: request.auth!.uid,
      changedByEmail: request.auth!.token.email ?? null,
      changedAt: FieldValue.serverTimestamp(),
    });
    await batch.commit();
    logger.info("GetGo upgrade test account created", {uid: authUser.uid, email, scenario, changedByUid: request.auth!.uid});
    return {uid: authUser.uid, email, scenario};
  } catch (error) {
    await getAuth().deleteUser(authUser.uid).catch(() => undefined);
    throw error;
  }
}

export const adminManageGetGoUpgradeTestAccount = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 120,
  memory: "512MiB",
}, withCallableErrorDetails("Upgrade test account could not be managed.", async (request: CallableRequest<TestAccountRequest>) => {
  const projectId = await requireTestAdmin(request);
  if (request.data?.action === "suggest") return {email: await nextTestEmail(), projectId};
  if (request.data?.action !== "create") throw new HttpsError("invalid-argument", "A valid action is required.");
  return {...await createTestAccount(request), projectId};
}));
