import {OpenAI} from "openai";
import {
  GetGoDynamicQuestionAiService,
  type GetGoDynamicQuestionAiProvider,
  type GetGoDynamicQuestionProposalResult,
  type GetGoStructuredAiRequest,
  type GetGoStructuredAiResponse,
} from "@tnp/getgo-logics/authoring";

interface GenerateDynamicQuestionProposalOptions {
  client: OpenAI;
  model: string;
  question: Record<string, unknown>;
  instructions?: string;
  currentDate?: string;
}

export interface GeneratedDynamicQuestionProposal {
  result: GetGoDynamicQuestionProposalResult;
  responseId: string;
  rawUsage: unknown;
}

class OpenAiDynamicQuestionProvider implements GetGoDynamicQuestionAiProvider {
  rawUsage: unknown;

  constructor(
    private readonly client: OpenAI,
    private readonly model: string
  ) {}

  async generate(request: GetGoStructuredAiRequest):
  Promise<GetGoStructuredAiResponse> {
    const response = await this.client.responses.create({
      model: this.model,
      reasoning: {effort: "medium"},
      input: [
        {role: "system", content: [{
          type: "input_text",
          text: request.systemPrompt,
          prompt_cache_breakpoint: {mode: "explicit"},
        }]},
        {role: "user", content: [{
          type: "input_text",
          text: JSON.stringify(request.payload),
        }]},
      ],
      text: {format: {
        type: "json_schema",
        name: "getgo_dynamic_question_proposal",
        strict: true,
        schema: request.outputSchema,
      }, verbosity: "low"},
      prompt_cache_key: request.promptCacheKey,
      prompt_cache_options: {mode: "explicit", ttl: "30m"},
    });
    this.rawUsage = response.usage;
    if (!response.output_text) {
      throw new Error("OpenAI returned no structured conversion proposal.");
    }
    return {
      output: JSON.parse(response.output_text),
      model: this.model,
      responseId: response.id,
      usage: {
        inputTokens: response.usage?.input_tokens ?? 0,
        outputTokens: response.usage?.output_tokens ?? 0,
        totalTokens: response.usage?.total_tokens ?? 0,
        cachedInputTokens:
          response.usage?.input_tokens_details?.cached_tokens ?? 0,
        cacheWriteTokens:
          response.usage?.input_tokens_details?.cache_write_tokens ?? 0,
      },
    };
  }
}

export async function generateDynamicQuestionProposal({
  client,
  model,
  question,
  instructions,
  currentDate = new Date().toISOString(),
}: GenerateDynamicQuestionProposalOptions):
Promise<GeneratedDynamicQuestionProposal> {
  const provider = new OpenAiDynamicQuestionProvider(client, model);
  const result = await new GetGoDynamicQuestionAiService(provider)
    .createProposal({question, instructions, currentDate});
  return {
    result,
    responseId: result.responseId ?? "",
    rawUsage: provider.rawUsage,
  };
}
