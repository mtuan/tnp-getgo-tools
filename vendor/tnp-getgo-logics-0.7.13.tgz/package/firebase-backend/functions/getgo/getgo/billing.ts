import {createHash, createHmac, randomBytes, timingSafeEqual} from "node:crypto";
import {SecretManagerServiceClient} from "@google-cloud/secret-manager";
import {FieldValue, getFirestore, Timestamp, type Transaction} from "firebase-admin/firestore";
import {HttpsError, onCall, onRequest, type CallableRequest} from "firebase-functions/v2/https";
import {onSchedule} from "firebase-functions/v2/scheduler";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";
import {applySubscriptionSource, hasActiveRecurringSubscription, subscriptionSources, type SubscriptionSourceRecord} from "./subscriptionEntitlements.js";
import {paymentReviewRef} from "./billingReviews.js";
export {submitGetGoPaymentReview, adminListGetGoPaymentReviews, adminResolveGetGoPaymentReview} from "./billingReviews.js";
export {syncGetGoAppleSubscription, getGoAppleServerNotifications} from "./appleBilling.js";
export {syncGetGoGooglePlaySubscription, getGoGooglePlayNotifications} from "./googlePlayBilling.js";

type LocaleText = {en: string; vi: string};
type Duration = {unit: "day" | "month" | "year"; value: number};
interface PaymentPackageRecord {id: string; platform?: "web" | "ios" | "android"; storeProductId?: string; name: LocaleText; type: "free" | "monthly" | "annual" | "one-time"; info: LocaleText; benefits: {en: string[]; vi: string[]}; price: {amount: number; currency: string}; active?: boolean; duration?: Duration}
interface PaymentSaleRecord {id: string; type?: "sale"; name: LocaleText; recurrence: "one-time" | "yearly"; startsOn: string; endsOn: string; discountPercent: number; packageIds?: string[]; targets?: {packageIds?: string[]}; enabled: boolean}
interface MarketplaceTopicRecord {title?: Partial<LocaleText>; state?: string; pricing?: {type?: string; amount?: number; currency?: string}}
type CheckoutPurchase =
  | {purchaseType: "subscription"; productId: string; product: PaymentPackageRecord; topicId?: never}
  | {purchaseType: "topic"; productId: string; topicId: string; product: PaymentPackageRecord};
interface GrantPurchaseRecord {parentUid: string; purchaseType: "subscription" | "topic"; productId: string; topicId?: string; orderId: string; transactionId: string; duration?: Duration}
interface VietQrConfig {environment: "sandbox" | "production"; apiBaseUrl: string; apiUsername: string; apiPassword: string; bankCode: string; bankAccount: string; userBankName: string; callbackUsername: string; callbackPassword: string; callbackSigningKey: string}
interface VietQrTransaction {bankaccount: string; amount: number; transType: "C" | "D"; content: string; transactionid: string; transactiontime: number; referencenumber: string; orderId: string}
interface BillingAuditContext {transactionId?: string; orderId?: string; parentUid?: string; environment: "sandbox" | "production"}

const secretManager = new SecretManagerServiceClient();
const VIETQR_SECRET = "GETGO_VIETQR_CONFIG";
const CHECKOUT_MS = 10 * 60 * 1000;
const TOKEN_SECONDS = 300;
const JWT_ISSUER = "getgo-vietqr";
const JWT_AUDIENCE = "vietqr-callback";
const AUDIT_RETENTION_MS = 90 * 24 * 60 * 60 * 1000;
let cachedApiToken: {token: string; expiresAt: number} | null = null;
let cachedConfig: {value: VietQrConfig; expiresAt: number} | null = null;

function paymentSimulationAvailable(): boolean {
  const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT;
  return process.env.FUNCTIONS_EMULATOR === "true"
    || Boolean(process.env.FIREBASE_EMULATOR_HUB)
    || projectId === "tnp-getgo-dev";
}

const requireAuth = (request: CallableRequest<unknown>): string => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  return request.auth.uid;
};
const dateKey = (date: Date) => date.toISOString().slice(0, 10);
const monthDay = (value: string) => value.slice(5);
function saleIsActive(sale: PaymentSaleRecord, now = new Date()): boolean {
  if (!sale.enabled) return false;
  const current = dateKey(now);
  if (sale.recurrence === "one-time") return current >= sale.startsOn && current <= sale.endsOn;
  const day = monthDay(current); const start = monthDay(sale.startsOn); const end = monthDay(sale.endsOn);
  return start <= end ? day >= start && day <= end : day >= start || day <= end;
}
const salePackageIds = (sale: PaymentSaleRecord): string[] => sale.targets?.packageIds ?? sale.packageIds ?? [];
async function loadPaymentSales(): Promise<PaymentSaleRecord[]> {
  const db = getFirestore();
  const [eventsSnapshot, legacySnapshot] = await Promise.all([
    db.collection("getgo-events").get(),
    db.collection("getgo-payment-sales").get(),
  ]);
  const events = eventsSnapshot.docs.map((doc) => doc.data() as PaymentSaleRecord).filter((event) => event.type === "sale");
  return eventsSnapshot.empty ? legacySnapshot.docs.map((doc) => doc.data() as PaymentSaleRecord) : events;
}
function isSubscribed(value: Record<string, unknown> | undefined): boolean {
  if (value?.packageId !== "premium") return false;
  if (value.subscriptionExpiresAt == null) return true;
  const expiry = value.subscriptionExpiresAt instanceof Timestamp ? value.subscriptionExpiresAt.toDate() : new Date(String(value.subscriptionExpiresAt));
  return Number.isFinite(expiry.getTime()) && expiry.getTime() > Date.now();
}
function parseConfig(source: string): VietQrConfig {
  let value: Partial<VietQrConfig>;
  try { value = JSON.parse(source) as Partial<VietQrConfig>; } catch { throw new Error("GETGO_VIETQR_CONFIG must contain valid JSON."); }
  const fields: Array<keyof VietQrConfig> = ["environment", "apiBaseUrl", "apiUsername", "apiPassword", "bankCode", "bankAccount", "userBankName", "callbackUsername", "callbackPassword", "callbackSigningKey"];
  for (const field of fields) if (typeof value[field] !== "string" || !value[field]?.trim()) throw new Error(`GETGO_VIETQR_CONFIG is missing ${field}.`);
  if (value.environment !== "sandbox" && value.environment !== "production") throw new Error("Invalid VietQR environment.");
  const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT;
  if (projectId === "tnp-getgo-dev" && value.environment !== "sandbox") throw new Error("GetGo DEV only accepts VietQR Sandbox configuration.");
  if (projectId === "tnp-getgo" && value.environment !== "production") throw new Error("GetGo production requires VietQR Production configuration.");
  const url = new URL(value.apiBaseUrl!);
  if (url.protocol !== "https:") throw new Error("VietQR API URL must use HTTPS.");
  return {...value, apiBaseUrl: url.origin} as VietQrConfig;
}
async function vietQrEnabled(): Promise<boolean> {
  const snapshot = await getFirestore().doc("getgo-config/payment-runtime").get();
  return snapshot.data()?.vietqr?.enabled === true;
}
async function requireVietQrConfig(): Promise<VietQrConfig> {
  if (!await vietQrEnabled()) throw new HttpsError("failed-precondition", "Payment service is temporarily unavailable.");
  if (cachedConfig && cachedConfig.expiresAt > Date.now()) return cachedConfig.value;
  const projectId = process.env.GCLOUD_PROJECT || process.env.GOOGLE_CLOUD_PROJECT;
  if (!projectId) throw new Error("Google Cloud project is unavailable.");
  const [version] = await secretManager.accessSecretVersion({name: `projects/${projectId}/secrets/${VIETQR_SECRET}/versions/latest`});
  const source = version.payload?.data?.toString();
  if (!source) throw new Error(`${VIETQR_SECRET} has no active value.`);
  const value = parseConfig(source);
  cachedConfig = {value, expiresAt: Date.now() + 30_000};
  cachedApiToken = null;
  return value;
}
function activeSaleFor(product: PaymentPackageRecord, sales: PaymentSaleRecord[]) {
  return sales.filter(item => salePackageIds(item).includes(product.id) && saleIsActive(item)).sort((a, b) => b.discountPercent - a.discountPercent)[0];
}
function priceFor(product: PaymentPackageRecord, sales: PaymentSaleRecord[]) {
  const sale = (product.platform || "web") === "web" ? activeSaleFor(product, sales) : undefined;
  const original = Number(product.price.amount);
  return {amount: sale ? Math.round(original * (100 - sale.discountPercent) / 100) : original, sale};
}
async function checkoutProduct(parentUid: string, input: {productId?: string; topicId?: string}): Promise<CheckoutPurchase> {
  const db = getFirestore();
  if (input.topicId) {
    if (input.productId) throw new HttpsError("invalid-argument", "Choose either a package or a topic.");
    const [topicSnapshot, entitlementSnapshot] = await Promise.all([
      db.doc(`getgo-marketplace-topics/${input.topicId}`).get(),
      db.doc(`getgo/${parentUid}/topicEntitlements/${input.topicId}`).get(),
    ]);
    if (!topicSnapshot.exists) throw new HttpsError("not-found", "Topic not found.");
    if (entitlementSnapshot.data()?.status === "active") throw new HttpsError("already-exists", "This topic has already been purchased.");
    const topic = topicSnapshot.data() as MarketplaceTopicRecord;
    const amount = Number(topic.pricing?.amount); const currency = topic.pricing?.currency;
    if (!['listed', 'featured'].includes(String(topic.state)) || topic.pricing?.type !== "paid") throw new HttpsError("failed-precondition", "Topic is unavailable for purchase.");
    if (!Number.isSafeInteger(amount) || amount <= 0 || currency !== "VND") throw new HttpsError("failed-precondition", "Topic price is invalid.");
    const title = {en: topic.title?.en || input.topicId, vi: topic.title?.vi || topic.title?.en || input.topicId};
    return {purchaseType: "topic", topicId: input.topicId, productId: `topic:${input.topicId}`, product: {id: `topic:${input.topicId}`, name: title, type: "one-time", info: title, benefits: {en: [], vi: []}, price: {amount, currency}}};
  }
  if (!input.productId) throw new HttpsError("invalid-argument", "A product or topic is required.");
  const productId = input.productId; const parentRef = db.doc(`getgo/${parentUid}`);
  const [productSnapshot, parentSnapshot, sourceSnapshot] = await Promise.all([
    db.doc(`getgo-payment-packages/${productId}`).get(), parentRef.get(), parentRef.collection("subscriptionSources").get(),
  ]);
  if (!productSnapshot.exists) throw new HttpsError("not-found", "Package not found.");
  const product = productSnapshot.data() as PaymentPackageRecord;
  if (product.active === false || !["monthly", "annual"].includes(product.type)) throw new HttpsError("failed-precondition", "Package is unavailable.");
  if ((product.platform || "web") !== "web") throw new HttpsError("failed-precondition", "This package must be purchased through its native app store.");
  if (hasActiveRecurringSubscription(subscriptionSources(sourceSnapshot, parentSnapshot.data()))) throw new HttpsError("failed-precondition", "Premium billing is already managed by an app store subscription.");
  return {purchaseType: "subscription", productId, product};
}
async function checkoutQuote(parentUid: string, input: {productId?: string; topicId?: string}) {
  const purchase = await checkoutProduct(parentUid, input); const {product} = purchase;
  const sales = await loadPaymentSales();
  const {amount: feeAmount, sale} = priceFor(product, sales);
  if (!Number.isSafeInteger(feeAmount) || feeAmount <= 0 || product.price.currency !== "VND") throw new HttpsError("failed-precondition", "Package price is invalid.");
  return {...purchase, feeAmount, amount: feeAmount, sale};
}
function durationFor(product: PaymentPackageRecord): Duration {
  if (product.duration && Number.isSafeInteger(product.duration.value) && product.duration.value > 0) return product.duration;
  if (product.type === "monthly") return {unit: "month", value: 1};
  if (product.type === "annual") return {unit: "year", value: 1};
  throw new Error("Package duration is missing.");
}
function addDuration(date: Date, duration: Duration): Date {
  const result = new Date(date);
  if (duration.unit === "day") { result.setUTCDate(result.getUTCDate() + duration.value); return result; }
  const day = result.getUTCDate(); result.setUTCDate(1);
  if (duration.unit === "month") result.setUTCMonth(result.getUTCMonth() + duration.value); else result.setUTCFullYear(result.getUTCFullYear() + duration.value);
  result.setUTCDate(Math.min(day, new Date(Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)).getUTCDate()));
  return result;
}
function grantPurchase(tx: Transaction, billing: GrantPurchaseRecord, paidAt: Timestamp, provider: "internal" | "vietqr", existingSources: Map<"web" | "apple" | "google", SubscriptionSourceRecord>, providerTransactionId?: string) {
  const db = getFirestore(); const parentRef = db.doc(`getgo/${billing.parentUid}`);
  if (billing.purchaseType === "topic") {
    if (!billing.topicId) throw new Error("Topic purchase is missing topicId.");
    const common = {topicId: billing.topicId, status: "active", access: "paid", purchaseType: "topic", productId: billing.productId, orderId: billing.orderId, transactionId: billing.transactionId, provider, paidAt, grantedAt: paidAt, updatedAt: paidAt, ...(providerTransactionId ? {providerTransactionId} : {})};
    tx.set(parentRef.collection("topicEntitlements").doc(billing.topicId), common, {merge: true});
    tx.set(parentRef.collection("topics").doc(billing.topicId), {parentId: billing.parentUid, topicId: billing.topicId, access: "paid", addedAt: paidAt, purchaseTransactionId: billing.transactionId, purchaseOrderId: billing.orderId}, {merge: true});
    return paidAt;
  }
  if (!billing.duration) throw new Error("Subscription purchase is missing duration.");
  const oldExpiry = existingSources.get("web")?.expiresAt; const oldDate = oldExpiry instanceof Timestamp ? oldExpiry.toDate() : new Date(0); const start = oldDate.getTime() > paidAt.toMillis() ? oldDate : paidAt.toDate(); const expiry = Timestamp.fromDate(addDuration(start, billing.duration));
  const common = {packageId: "premium", status: "active", provider, paymentMethod: provider === "internal" ? "coupon" : "vietqr", productId: billing.productId, transactionId: billing.transactionId, ...(providerTransactionId ? {providerTransactionId} : {}), paidAt, startsAt: Timestamp.fromDate(start), expiresAt: expiry, updatedAt: paidAt};
  tx.set(parentRef.collection("subscriptions").doc("family_premium"), common, {merge: true});
  tx.set(parentRef.collection("entitlements").doc("family_premium"), {...common, entitlement: "family_premium"}, {merge: true});
  applySubscriptionSource(tx, parentRef, existingSources, "web", {provider: "web", status: "active", productId: billing.productId, expiresAt: expiry, autoRenewing: false, paymentMethod: provider === "internal" ? "coupon" : "vietqr", transactionId: billing.transactionId});
  return expiry;
}
const maskedAccount = (value: unknown): unknown => typeof value === "string" && value.length > 4 ? `${"*".repeat(Math.min(8, value.length - 4))}${value.slice(-4)}` : value;
function sanitizedAuditValue(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sanitizedAuditValue);
  if (value instanceof Timestamp || value instanceof Date) return value;
  if (!value || typeof value !== "object") return value;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>)
    .filter(([key]) => !["access_token", "authorization", "password", "callbacksigningkey", "qrcode"].includes(key.toLowerCase()))
    .map(([key, item]) => [key, ["bankaccount"].includes(key.toLowerCase()) ? maskedAccount(item) : sanitizedAuditValue(item)]));
}
const auditError = (error: unknown) => ({message: error instanceof Error ? error.message : String(error), type: error instanceof Error ? error.name : "Error"});
async function writeBillingAudit(event: string, context: BillingAuditContext, detail: Record<string, unknown> = {}): Promise<void> {
  const now = Timestamp.now();
  try {
    await getFirestore().collection("getgo-billing-events").add({
      schemaVersion: 1, provider: "vietqr", event, ...context,
      ...sanitizedAuditValue(detail) as Record<string, unknown>,
      createdAt: now, expiresAt: Timestamp.fromMillis(now.toMillis() + AUDIT_RETENTION_MS),
    });
  } catch (error) {
    console.error("Billing audit write failed", {event, transactionId: context.transactionId, orderId: context.orderId, error: auditError(error)});
  }
}
async function callVietQr(config: VietQrConfig, path: string, body: unknown, authorization: string, context: BillingAuditContext, operation: string) {
  const startedAt = Date.now();
  await writeBillingAudit(`${operation}.requested`, context, {direction: "outbound", endpoint: path, request: body ?? {}});
  try {
    const response = await fetch(`${config.apiBaseUrl}${path}`, {method: "POST", headers: {"Content-Type": "application/json", Authorization: authorization}, ...(body ? {body: JSON.stringify(body)} : {}), redirect: "error", signal: AbortSignal.timeout(20_000)});
    const data = await response.json() as Record<string, unknown>;
    await writeBillingAudit(`${operation}.responded`, context, {direction: "inbound", endpoint: path, httpStatus: response.status, success: response.ok && data.status !== "FAILED", durationMs: Date.now() - startedAt, response: data});
    if (!response.ok || data.status === "FAILED") throw new Error(`VietQR HTTP ${response.status}: ${String(data.message || "Request failed")}`);
    return data;
  } catch (error) {
    await writeBillingAudit(`${operation}.failed`, context, {direction: "outbound", endpoint: path, success: false, durationMs: Date.now() - startedAt, error: auditError(error)});
    throw error;
  }
}
async function apiToken(config: VietQrConfig, context: BillingAuditContext) {
  if (cachedApiToken && cachedApiToken.expiresAt > Date.now() + 10_000) return cachedApiToken.token;
  const basic = Buffer.from(`${config.apiUsername}:${config.apiPassword}`).toString("base64");
  const data = await callVietQr(config, "/vqr/api/token_generate", null, `Basic ${basic}`, context, "vietqr.token");
  if (typeof data.access_token !== "string" || !Number.isFinite(Number(data.expires_in))) throw new Error("Invalid VietQR token response.");
  cachedApiToken = {token: data.access_token, expiresAt: Date.now() + Number(data.expires_in) * 1000};
  return cachedApiToken.token;
}
const b64 = (value: string | Buffer) => Buffer.from(value).toString("base64url");
function signCallbackToken(config: VietQrConfig): string {
  const now = Math.floor(Date.now() / 1000);
  const content = `${b64(JSON.stringify({alg: "HS512", typ: "JWT"}))}.${b64(JSON.stringify({username: config.callbackUsername, scope: "callback", iss: JWT_ISSUER, aud: JWT_AUDIENCE, iat: now, exp: now + TOKEN_SECONDS}))}`;
  return `${content}.${createHmac("sha512", config.callbackSigningKey).update(content).digest("base64url")}`;
}
function verifyCallbackToken(token: string, config: VietQrConfig): boolean {
  const parts = token.split("."); if (parts.length !== 3) return false;
  const content = `${parts[0]}.${parts[1]}`; const actual = Buffer.from(parts[2], "base64url"); const expected = createHmac("sha512", config.callbackSigningKey).update(content).digest();
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return false;
  try { const data = JSON.parse(Buffer.from(parts[1], "base64url").toString()) as Record<string, unknown>; return data.scope === "callback" && data.iss === JWT_ISSUER && data.aud === JWT_AUDIENCE && typeof data.exp === "number" && data.exp > Date.now() / 1000; } catch { return false; }
}
function validateTransaction(body: unknown): VietQrTransaction {
  if (!body || typeof body !== "object" || Array.isArray(body)) throw new Error("Body must be an object.");
  const value = body as Record<string, unknown>;
  for (const field of ["bankaccount", "content", "transactionid", "referencenumber", "orderId"]) if (typeof value[field] !== "string" || !value[field].trim()) throw new Error(`Invalid ${field}.`);
  if (!Number.isSafeInteger(value.amount) || Number(value.amount) <= 0) throw new Error("Invalid amount.");
  if (!Number.isSafeInteger(value.transactiontime) || Number(value.transactiontime) <= 0) throw new Error("Invalid transactiontime.");
  if (value.transType !== "C" && value.transType !== "D") throw new Error("Invalid transType.");
  return value as unknown as VietQrTransaction;
}
const failure = (reason: string, message: string) => ({error: true, errorReason: reason, toastMessage: message, object: null});

function checkoutStatusRef(parentUid: string, transactionId: string) {
  return getFirestore().doc(`getgo/${parentUid}/checkoutStatuses/${transactionId}`);
}

function paymentHistoryRef(parentUid: string, paymentId: string) {
  return getFirestore().doc(`getgo/${parentUid}/paymentHistory/${paymentId}`);
}

function paymentNotification(status: "paid" | "review-required", billing: Record<string, unknown>, createdAt: Timestamp) {
  const transactionId = String(billing.transactionId || "");
  const orderId = String(billing.orderId || transactionId);
  const productName = billing.productName && typeof billing.productName === "object" ? billing.productName as Partial<LocaleText> : {};
  const fallbackName = String(billing.productId || orderId);
  const params = {orderId, productNameEn: productName.en || productName.vi || fallbackName, productNameVi: productName.vi || productName.en || fallbackName};
  const purchaseType = billing.purchaseType === "topic" ? "topic" : "subscription";
  const titleKey = status === "paid"
    ? `notifications.events.${purchaseType === "topic" ? "topicPurchasedTitle" : "subscriptionPurchasedTitle"}`
    : "notifications.events.paymentReviewRequiredTitle";
  const messageKey = status === "paid" ? null : "notifications.events.paymentReviewRequiredMessage";
  return {
    ref: getFirestore().doc(`getgo/${String(billing.parentUid)}/notifications/payment-${transactionId}-${status}`),
    data: {
      schemaVersion: 1,
      kind: "payment",
      titleKey,
      ...(messageKey ? {messageKey} : {}),
      params,
      route: "/parent/subscribe",
      createdAt,
      readAt: null,
    },
  };
}

async function expireBillingTransaction(transactionId: string): Promise<boolean> {
  const db = getFirestore();
  const transactionRef = db.doc(`getgo-billing-transactions/${transactionId}`);
  let auditContext: BillingAuditContext | null = null;
  const expired = await db.runTransaction(async tx => {
    const snapshot = await tx.get(transactionRef);
    if (!snapshot.exists) return false;
    const value = snapshot.data()!;
    if (!["creating", "pending"].includes(value.status) || !(value.checkoutExpiresAt instanceof Timestamp) || value.checkoutExpiresAt.toMillis() > Date.now()) return false;
    auditContext = {transactionId, orderId: String(value.orderId || ""), parentUid: String(value.parentUid || ""), environment: value.environment === "production" ? "production" : "sandbox"};
    const expiredAt = Timestamp.now();
    tx.update(transactionRef, {status: "expired", expiredAt, updatedAt: expiredAt});
    if (typeof value.orderId === "string" && value.orderId) tx.set(db.doc(`getgo-billing-orders/${value.orderId}`), {status: "expired", expiredAt, updatedAt: expiredAt}, {merge: true});
    tx.set(checkoutStatusRef(String(value.parentUid), transactionId), {status: "expired", expiredAt, updatedAt: expiredAt}, {merge: true});
    tx.delete(db.doc(`getgo-billing-pending/${transactionId}`));
    return true;
  });
  if (expired && auditContext) await writeBillingAudit("checkout.expired", auditContext, {success: true});
  return expired;
}

export const getGetGoBillingSummary = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Billing options could not be loaded.", async (request: CallableRequest<void>) => {
  const uid = requireAuth(request); const db = getFirestore();
  const [packagesSnapshot, sales, parentSnapshot, subscriptionSnapshot, webPaymentsEnabled] = await Promise.all([
    db.collection("getgo-payment-packages").get(),
    loadPaymentSales(),
    db.doc(`getgo/${uid}`).get(),
    db.doc(`getgo/${uid}/subscriptions/family_premium`).get(),
    vietQrEnabled(),
  ]);
  const products = packagesSnapshot.docs.map(doc => doc.data() as PaymentPackageRecord)
    .filter(item => item.active !== false && ["free", "monthly", "annual"].includes(item.type))
    .sort((a, b) => ({free: 0, monthly: 1, annual: 2, "one-time": 3}[a.type] - {free: 0, monthly: 1, annual: 2, "one-time": 3}[b.type]))
    .map(item => { const platform = item.platform || "web"; const priced = priceFor(item, sales); const sale = platform === "web" ? priced.sale : activeSaleFor(item, sales); return {id: item.id, platform, ...(item.storeProductId ? {storeProductId: item.storeProductId} : {}), type: item.type, name: item.name, info: item.info, benefits: item.benefits, amount: priced.amount, currency: item.price.currency, billingPeriod: item.type === "annual" ? "year" : item.type === "monthly" ? "month" : null, providers: item.type !== "free" && platform === "web" && webPaymentsEnabled ? ["vietqr"] : [], ...(sale ? {discountPercent: sale.discountPercent, sale: {id: sale.id, name: sale.name, discountPercent: sale.discountPercent, originalAmount: Number(item.price.amount)}} : {})}; });
  const subscribed = isSubscribed(parentSnapshot.data());
  const currentProductId = subscribed && typeof subscriptionSnapshot.data()?.productId === "string" ? subscriptionSnapshot.data()!.productId : null;
  const subscriptionProvider = subscribed && typeof parentSnapshot.data()?.subscriptionProvider === "string" ? parentSnapshot.data()!.subscriptionProvider : null;
  return {schemaVersion: 2, subscribed, currentProductId, subscriptionProvider, webPaymentsEnabled, products};
}));

export const quoteGetGoCheckout = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Checkout quote could not be loaded.", async (request: CallableRequest<{productId?: string; topicId?: string}>) => {
  const parentUid = requireAuth(request); const quote = await checkoutQuote(parentUid, request.data || {});
  const config = await requireVietQrConfig();
  return {purchaseType: quote.purchaseType, productId: quote.productId, ...(quote.topicId ? {topicId: quote.topicId} : {}), productName: quote.product.name, payeeName: config.userBankName, bankCode: config.bankCode, feeAmount: quote.feeAmount, amount: quote.amount, currency: "VND"};
}));

export const createGetGoCheckout = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Checkout could not be started.", async (request: CallableRequest<{productId?: string; topicId?: string}>) => {
  const parentUid = requireAuth(request); const db = getFirestore(); const quote = await checkoutQuote(parentUid, request.data || {});
  const {purchaseType, productId, topicId, product, feeAmount, amount, sale} = quote;
  const config = await requireVietQrConfig(); const transactionRef = db.collection("getgo-billing-transactions").doc(); const orderId = randomBytes(6).toString("hex").toUpperCase();
  const orderRef = db.doc(`getgo-billing-orders/${orderId}`); const now = Timestamp.now(); const checkoutExpiresAt = Timestamp.fromMillis(Date.now() + CHECKOUT_MS); const content = `GETGO ${orderId}`;
  const orderSnapshot = {transactionId: transactionRef.id, parentUid, purchaseType, productId, ...(topicId ? {topicId} : {}), productName: product.name, provider: "vietqr", paymentMethod: "vietqr", feeAmount, amount, currency: "VND", content, ...(sale ? {saleId: sale.id, discountPercent: sale.discountPercent} : {})};
  const auditContext: BillingAuditContext = {transactionId: transactionRef.id, orderId, parentUid, environment: config.environment};
  const batch = db.batch();
  batch.create(transactionRef, {...orderSnapshot, orderId, environment: config.environment, status: "creating", ...(purchaseType === "subscription" ? {duration: durationFor(product)} : {}), createdAt: now, updatedAt: now, checkoutExpiresAt});
  batch.create(orderRef, {...orderSnapshot, status: "creating", checkoutExpiresAt, createdAt: now, updatedAt: now});
  batch.create(db.doc(`getgo-billing-pending/${transactionRef.id}`), {transactionId: transactionRef.id, orderId, expiresAt: checkoutExpiresAt, createdAt: now});
  batch.create(checkoutStatusRef(parentUid, transactionRef.id), {...orderSnapshot, id: transactionRef.id, status: "creating", checkoutExpiresAt, createdAt: now, updatedAt: now});
  await batch.commit();
  await writeBillingAudit("checkout.created", auditContext, {success: true, productId, feeAmount, amount, currency: "VND", content, checkoutExpiresAt});
  try {
    const qr = await callVietQr(config, "/vqr/api/qr/generate-customer", {bankCode: config.bankCode, bankAccount: config.bankAccount, userBankName: config.userBankName, amount, content, orderId, qrType: 0, transType: "C"}, `Bearer ${await apiToken(config, auditContext)}`, auditContext, "vietqr.qr");
    if (typeof qr.qrCode !== "string" || !qr.qrCode || typeof qr.content !== "string" || Number(qr.amount) !== amount) throw new Error("Invalid VietQR QR response.");
    const pendingAt = Timestamp.now();
    const pendingBatch = db.batch();
    pendingBatch.update(transactionRef, {status: "pending", content: qr.content, qrCode: qr.qrCode, updatedAt: pendingAt});
    pendingBatch.update(orderRef, {status: "pending", content: qr.content, updatedAt: pendingAt});
    pendingBatch.set(checkoutStatusRef(parentUid, transactionRef.id), {status: "pending", content: qr.content, updatedAt: pendingAt}, {merge: true});
    await pendingBatch.commit();
    await writeBillingAudit("checkout.pending", auditContext, {success: true, amount, content: qr.content});
    return {transactionId: transactionRef.id, presentation: {type: "qr", qrCode: qr.qrCode}, amount, currency: "VND", content: qr.content, environment: config.environment, expiresAt: checkoutExpiresAt.toDate().toISOString()};
  } catch (error) {
    const failedAt = Timestamp.now();
    const failedBatch = db.batch();
    failedBatch.update(transactionRef, {status: "failed", failedAt, updatedAt: failedAt});
    failedBatch.update(orderRef, {status: "failed", failedAt, updatedAt: failedAt});
    failedBatch.set(checkoutStatusRef(parentUid, transactionRef.id), {status: "failed", failedAt, updatedAt: failedAt}, {merge: true});
    failedBatch.delete(db.doc(`getgo-billing-pending/${transactionRef.id}`));
    await failedBatch.commit();
    await writeBillingAudit("checkout.failed", auditContext, {success: false, error: auditError(error)});
    throw error;
  }
}));

export const cancelGetGoCheckout = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Checkout could not be cancelled.", async (request: CallableRequest<{transactionId?: string}>) => {
  const parentUid = requireAuth(request); const transactionId = request.data?.transactionId;
  if (!transactionId) throw new HttpsError("invalid-argument", "A transaction ID is required.");
  const db = getFirestore(); const transactionRef = db.doc(`getgo-billing-transactions/${transactionId}`);
  let auditContext: BillingAuditContext | null = null;
  const result = await db.runTransaction(async tx => {
    const snapshot = await tx.get(transactionRef);
    if (!snapshot.exists || snapshot.data()!.parentUid !== parentUid) throw new HttpsError("not-found", "Transaction not found.");
    const value = snapshot.data()!;
    auditContext = {transactionId, orderId: String(value.orderId || ""), parentUid, environment: value.environment === "production" ? "production" : "sandbox"};
    if (value.status === "paid" || value.status === "cancelled") return {status: String(value.status), didCancel: false};
    if (!["creating", "pending"].includes(value.status)) return {status: String(value.status), didCancel: false};
    const cancelledAt = Timestamp.now();
    tx.update(transactionRef, {status: "cancelled", cancelledAt, updatedAt: cancelledAt});
    if (typeof value.orderId === "string" && value.orderId) tx.set(db.doc(`getgo-billing-orders/${value.orderId}`), {status: "cancelled", cancelledAt, updatedAt: cancelledAt}, {merge: true});
    tx.set(checkoutStatusRef(parentUid, transactionId), {status: "cancelled", cancelledAt, updatedAt: cancelledAt}, {merge: true});
    tx.delete(db.doc(`getgo-billing-pending/${transactionId}`));
    return {status: "cancelled", didCancel: true};
  });
  if (result.didCancel && auditContext) await writeBillingAudit("checkout.cancelled", auditContext, {success: true});
  return {status: result.status};
}));

export const simulateGetGoCheckout = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Sandbox payment simulation could not be started.", async (request: CallableRequest<{transactionId?: string}>) => {
  const parentUid = requireAuth(request); const transactionId = request.data?.transactionId;
  if (!transactionId) throw new HttpsError("invalid-argument", "A transaction is required.");
  const config = await requireVietQrConfig();
  if (!paymentSimulationAvailable()) throw new HttpsError("failed-precondition", "Payment simulation is only available in local and development environments.");
  if (config.environment !== "sandbox") throw new HttpsError("failed-precondition", "Payment simulation is only available in Sandbox.");
  const db = getFirestore();
  const transactionRef = db.doc(`getgo-billing-transactions/${transactionId}`);
  const snapshot = await transactionRef.get();
  if (!snapshot.exists || snapshot.data()!.parentUid !== parentUid) throw new HttpsError("not-found", "Transaction not found.");
  const transaction = snapshot.data()!;
  if (transaction.status !== "pending" || !(transaction.checkoutExpiresAt instanceof Timestamp) || transaction.checkoutExpiresAt.toMillis() <= Date.now()) throw new HttpsError("failed-precondition", "Transaction is no longer pending.");
  const auditContext: BillingAuditContext = {transactionId, orderId: String(transaction.orderId || ""), parentUid, environment: config.environment};
  const simulationRequestedAt = Timestamp.now();
  await transactionRef.update({paymentMode: "mock", simulationRequestedAt, updatedAt: simulationRequestedAt});
  try {
    await callVietQr(config, "/vqr/bank/api/test/transaction-callback", {
      bankAccount: config.bankAccount,
      bankCode: config.bankCode,
      content: transaction.content,
      amount: transaction.amount,
      transType: "C",
    }, `Bearer ${await apiToken(config, auditContext)}`, auditContext, "sandbox.simulation");
  } catch (error) {
    await transactionRef.update({paymentMode: FieldValue.delete(), simulationRequestedAt: FieldValue.delete(), updatedAt: Timestamp.now()});
    throw error;
  }
  await writeBillingAudit("sandbox.simulation.accepted", auditContext, {success: true});
  return {accepted: true};
}));

export const getGetGoBillingTransaction = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("The billing transaction could not be loaded.", async (request: CallableRequest<{transactionId?: string}>) => {
  const uid = requireAuth(request); const id = request.data?.transactionId; if (!id) throw new HttpsError("invalid-argument", "A transaction ID is required.");
  const ref = getFirestore().doc(`getgo-billing-transactions/${id}`); const snapshot = await ref.get(); if (!snapshot.exists) throw new HttpsError("not-found", "Transaction not found.");
  const value = snapshot.data()!; if (value.parentUid !== uid) throw new HttpsError("permission-denied", "Transaction belongs to another account.");
  if (["creating", "pending"].includes(value.status) && value.checkoutExpiresAt instanceof Timestamp && value.checkoutExpiresAt.toMillis() <= Date.now()) {
    if (await expireBillingTransaction(id)) value.status = "expired";
  }
  const expires = value.status === "paid" ? (value.subscriptionExpiresAt || value.paidAt) : value.checkoutExpiresAt;
  return {
    id: snapshot.id, status: value.status, purchaseType: value.purchaseType || "subscription", productId: value.productId, topicId: value.topicId, provider: value.provider,
    amount: value.amount, currency: value.currency, content: value.content, orderId: value.orderId, productName: value.productName, providerTransactionId: value.providerTransactionId,
    paidAt: value.paidAt instanceof Timestamp ? value.paidAt.toDate().toISOString() : value.paidAt,
    expiresAt: expires instanceof Timestamp ? expires.toDate().toISOString() : expires,
    isMock: value.paymentMode === "mock" || value.simulationRequestedAt instanceof Timestamp,
  };
}));

export const listGetGoPaymentHistory = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Payment history could not be loaded.", async (request: CallableRequest<void>) => {
  const parentUid = requireAuth(request); const db = getFirestore();
  const history = await db.collection(`getgo/${parentUid}/paymentHistory`).orderBy("transferredAt", "desc").limit(50).get();
  const reviews = history.empty ? [] : await db.getAll(...history.docs.map(doc => paymentReviewRef(parentUid, doc.id)));
  const reviewsByPaymentId = new Map(reviews.filter(review => review.exists).map(review => [String(review.get("paymentId") || ""), review.data()!]));
  const items = new Map<string, Record<string, unknown>>();
  const add = (id: string, value: Record<string, unknown>) => {
    const providerTransactionId = String(value.providerTransactionId || id);
    if (items.has(providerTransactionId)) return;
    const transferredAt = value.transferredAt || value.providerTransactionTime || value.paidAt || value.createdAt;
    if (!(transferredAt instanceof Timestamp)) return;
    const review = reviewsByPaymentId.get(id);
    items.set(providerTransactionId, {
      id, providerTransactionId, orderId: String(value.orderId || ""), productId: String(value.productId || ""),
      productName: value.productName, amount: Number(value.amount || 0), currency: String(value.currency || "VND"), transferredAt: transferredAt.toDate().toISOString(),
      isMock: value.isMock === true || value.paymentMode === "mock" || value.simulationRequestedAt instanceof Timestamp,
      outcome: value.outcome, reason: value.reason,
      ...(review ? {review: {
        status: review.status === "resolved" ? "resolved" : "pending",
        note: String(review.note || ""), feedback: String(review.feedback || ""),
        requestedAt: review.requestedAt instanceof Timestamp ? review.requestedAt.toDate().toISOString() : null,
        updatedAt: review.updatedAt instanceof Timestamp ? review.updatedAt.toDate().toISOString() : null,
        resolvedAt: review.resolvedAt instanceof Timestamp ? review.resolvedAt.toDate().toISOString() : null,
      }} : {}),
    });
  };
  history.docs.forEach(doc => add(doc.id, doc.data()));
  return {items: [...items.values()].sort((left, right) => String(right.transferredAt).localeCompare(String(left.transferredAt))).slice(0, 50)};
}));

export const clearGetGoPaymentHistory = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Payment history could not be cleared.", async (request: CallableRequest<void>) => {
  const parentUid = requireAuth(request); const db = getFirestore();
  if (!paymentSimulationAvailable()) throw new HttpsError("failed-precondition", "Payment history can only be cleared in local or development environments.");
  const history = db.collection(`getgo/${parentUid}/paymentHistory`);
  let deletedCount = 0;
  while (true) {
    const snapshot = await history.limit(400).get();
    if (snapshot.empty) break;
    const batch = db.batch();
    snapshot.docs.forEach(doc => batch.delete(doc.ref));
    await batch.commit();
    deletedCount += snapshot.size;
  }
  const reviewSnapshot = await db.collection("getgo-payment-reviews").where("parentUid", "==", parentUid).get();
  if (!reviewSnapshot.empty) {
    const writer = db.bulkWriter();
    reviewSnapshot.docs.forEach(doc => writer.delete(doc.ref));
    await writer.close();
  }
  await db.doc(`getgo/${parentUid}/billingPreferences/paymentHistory`).delete();
  return {cleared: true, deletedCount};
}));

export const getGoVietQrApi = onRequest({region: DEPLOYMENT_REGION, invoker: "public", maxInstances: 10, timeoutSeconds: 60}, async (request, response) => {
  response.set("Cache-Control", "private, no-store");
  if (request.method !== "POST") { response.status(405).set("Allow", "POST").json(failure("METHOD_NOT_ALLOWED", "POST is required.")); return; }
  let config: VietQrConfig; try { config = await requireVietQrConfig(); } catch (error) { console.error("VietQR configuration error", error); response.status(503).json(failure("SERVICE_UNAVAILABLE", "Payment service is unavailable.")); return; }
  const path = request.path.replace(/\/$/, "");
  if (path === "/vqr/api/token_generate") {
    const context: BillingAuditContext = {environment: config.environment};
    await writeBillingAudit("callback.token.requested", context, {direction: "inbound", endpoint: path});
    const auth = request.headers.authorization || ""; if (!auth.startsWith("Basic ")) { await writeBillingAudit("callback.token.rejected", context, {success: false, httpStatus: 400, error: {code: "INVALID_AUTH_HEADER"}}); response.status(400).json({status: "FAILED", message: "INVALID_AUTH_HEADER"}); return; }
    const actual = Buffer.from(auth.slice(6), "base64"); const expected = Buffer.from(`${config.callbackUsername}:${config.callbackPassword}`);
    if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) { await writeBillingAudit("callback.token.rejected", context, {success: false, httpStatus: 401, error: {code: "INVALID_CREDENTIALS"}}); response.status(401).json({status: "FAILED", message: "INVALID_CREDENTIALS"}); return; }
    await writeBillingAudit("callback.token.responded", context, {success: true, httpStatus: 200, response: {token_type: "Bearer", expires_in: TOKEN_SECONDS}});
    response.json({access_token: signCallbackToken(config), token_type: "Bearer", expires_in: TOKEN_SECONDS}); return;
  }
  if (path !== "/vqr/bank/api/transaction-sync") { response.status(404).json(failure("NOT_FOUND", "Endpoint not found.")); return; }
  const auth = request.headers.authorization || ""; if (!auth.startsWith("Bearer ") || !verifyCallbackToken(auth.slice(7), config)) { response.status(401).json(failure("INVALID_TOKEN", "Invalid or expired token.")); return; }
  let body: VietQrTransaction; try { body = validateTransaction(request.body); } catch (error) { response.status(400).json(failure("INVALID_TRANSACTION", error instanceof Error ? error.message : "Invalid transaction.")); return; }
  let callbackContext: BillingAuditContext = {orderId: body.orderId, environment: config.environment};
  try {
    const db = getFirestore(); const order = await db.doc(`getgo-billing-orders/${body.orderId}`).get(); if (!order.exists) throw new Error("Order not found.");
    const transactionId = String(order.data()!.transactionId || ""); const billingRef = db.doc(`getgo-billing-transactions/${transactionId}`); const paymentId = createHash("sha256").update(body.transactionid).digest("hex"); const claimRef = db.doc(`getgo-billing-provider-transactions/${paymentId}`);
    callbackContext = {transactionId, orderId: body.orderId, parentUid: String(order.data()!.parentUid || ""), environment: config.environment};
    await writeBillingAudit("callback.transaction.received", callbackContext, {direction: "inbound", endpoint: path, request: body});
    const providerId = await db.runTransaction(async tx => {
      const billingSnapshot = await tx.get(billingRef); if (!billingSnapshot.exists) throw new Error("Order not found."); const billing = billingSnapshot.data()!;
      const parentRef = db.doc(`getgo/${billing.parentUid}`);
      const [claim, parent, sourcesSnapshot] = await Promise.all([tx.get(claimRef), tx.get(parentRef), tx.get(parentRef.collection("subscriptionSources"))]);
      if (claim.exists) return body.transactionid;
      const transferredAt = Timestamp.fromMillis(body.transactiontime); const processedAt = Timestamp.now();
      const historyRef = paymentHistoryRef(String(billing.parentUid), paymentId);
      const isMock = billing.paymentMode === "mock" || billing.simulationRequestedAt instanceof Timestamp;
      const payment = {transactionId, orderId: body.orderId, parentUid: billing.parentUid, productId: billing.productId, productName: billing.productName, provider: "vietqr", providerTransactionId: body.transactionid, amount: body.amount, currency: billing.currency || "VND", content: body.content, referenceNumber: body.referencenumber, transferredAt, processedAt, isMock};
      const reject = (reason: "duplicate-payment" | "payment-window-expired" | "checkout-cancelled" | "checkout-failed" | "payment-mismatch" | "not-payable") => {
        tx.set(historyRef, {...payment, outcome: "rejected", reason});
        tx.set(claimRef, {transactionId, orderId: body.orderId, provider: "vietqr", rejected: true, reason, createdAt: processedAt});
        const notification = paymentNotification("review-required", payment, processedAt);
        tx.set(notification.ref, notification.data);
      };
      const matches = Number(billing.amount) === body.amount && String(billing.content) === body.content && billing.environment === config.environment && billing.provider === "vietqr" && body.transType === "C" && body.bankaccount === config.bankAccount && body.orderId === billing.orderId;
      if (!matches) { reject("payment-mismatch"); return body.transactionid; }
      if (billing.status === "paid") {
        if (billing.providerTransactionId === body.transactionid) return body.transactionid;
        const duplicateRef = db.doc(`getgo-billing-duplicate-payments/${claimRef.id}`);
        tx.set(duplicateRef, {...payment, providerTransactionTime: transferredAt, status: "needs-review", createdAt: processedAt});
        reject("duplicate-payment");
        tx.set(order.ref, {duplicatePaymentCount: FieldValue.increment(1), lastDuplicatePaymentAt: processedAt, updatedAt: processedAt}, {merge: true});
        return body.transactionid;
      }
      if (!(billing.checkoutExpiresAt instanceof Timestamp) || transferredAt.toMillis() > billing.checkoutExpiresAt.toMillis()) { reject("payment-window-expired"); return body.transactionid; }
      if (billing.status === "cancelled") { reject("checkout-cancelled"); return body.transactionid; }
      if (billing.status === "failed") { reject("checkout-failed"); return body.transactionid; }
      if (!["creating", "pending", "expired"].includes(String(billing.status))) { reject("not-payable"); return body.transactionid; }
      const paidAt = Timestamp.now(); const accessExpiresAt = grantPurchase(tx, {...billing, transactionId} as GrantPurchaseRecord, paidAt, "vietqr", subscriptionSources(sourcesSnapshot, parent.data()), body.transactionid);
      const settlement = {amount: body.amount};
      tx.update(billingRef, {...settlement, status: "paid", providerTransactionId: body.transactionid, referenceNumber: body.referencenumber, providerTransactionTime: Timestamp.fromMillis(body.transactiontime), paidAt, ...(billing.purchaseType !== "topic" ? {subscriptionExpiresAt: accessExpiresAt} : {}), updatedAt: paidAt});
      tx.set(order.ref, {...settlement, status: "paid", providerTransactionId: body.transactionid, paidAt, updatedAt: paidAt}, {merge: true});
      tx.set(checkoutStatusRef(String(billing.parentUid), transactionId), {status: "paid", amount: body.amount, paidAt, expiresAt: accessExpiresAt, updatedAt: paidAt}, {merge: true});
      const notification = paymentNotification("paid", {...billing, transactionId}, paidAt);
      tx.set(notification.ref, notification.data);
      tx.delete(db.doc(`getgo-billing-pending/${transactionId}`));
      tx.set(historyRef, {...payment, outcome: "granted", reason: "access-granted", grantedAt: paidAt});
      tx.set(claimRef, {transactionId, orderId: body.orderId, provider: "vietqr", createdAt: paidAt}); return body.transactionid;
    });
    const result = {error: false, errorReason: null, toastMessage: "OK", object: {reftransactionid: providerId}};
    await writeBillingAudit("callback.transaction.accepted", callbackContext, {success: true, httpStatus: 200, response: result});
    response.json(result);
  } catch (error) {
    console.error("VietQR transaction sync rejected", {orderId: body.orderId, transactionId: body.transactionid, message: error instanceof Error ? error.message : String(error)});
    const result = failure("PAYMENT_MISMATCH", error instanceof Error ? error.message : "Payment mismatch.");
    await writeBillingAudit("callback.transaction.rejected", callbackContext, {success: false, httpStatus: 400, request: body, response: result, error: auditError(error)});
    response.status(400).json(result);
  }
});

export const expireGetGoBillingCheckouts = onSchedule({
  region: DEPLOYMENT_REGION,
  schedule: "every 5 minutes",
  timeZone: "Asia/Ho_Chi_Minh",
  retryCount: 0,
}, async () => {
  const snapshot = await getFirestore().collection("getgo-billing-pending")
    .where("expiresAt", "<=", Timestamp.now()).limit(100).get();
  await Promise.all(snapshot.docs.map(doc => expireBillingTransaction(doc.id)));
});
