import {createHash} from "node:crypto";
import {getApp} from "firebase-admin/app";
import {getFirestore, Timestamp} from "firebase-admin/firestore";
import {defineSecret} from "firebase-functions/params";
import {HttpsError, onCall, onRequest, type CallableRequest} from "firebase-functions/v2/https";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";
import {applySubscriptionSource, subscriptionSources} from "./subscriptionEntitlements.js";

interface GooglePlayConfig {packageName: string}
interface GooglePurchaseInput {productId: string; purchaseToken: string}
interface GoogleSubscription {
  subscriptionState?: string;
  externalAccountIdentifiers?: {obfuscatedExternalAccountId?: string};
  lineItems?: Array<{productId?: string; expiryTime?: string; autoRenewingPlan?: {autoRenewEnabled?: boolean}}>;
}

const configSecret = defineSecret("GETGO_GOOGLE_PLAY_IAP_CONFIG");
const productIds = new Set(["getgo_family_monthly", "getgo_family_annual"]);

function config(): GooglePlayConfig {
  const value = JSON.parse(configSecret.value()) as Partial<GooglePlayConfig>;
  if (!value.packageName) throw new Error("GETGO_GOOGLE_PLAY_IAP_CONFIG requires packageName.");
  return value as GooglePlayConfig;
}

const accountId = (uid: string) => createHash("sha256").update(uid).digest("hex");
const tokenId = (token: string) => createHash("sha256").update(token).digest("hex");

async function verify(purchaseToken: string): Promise<GoogleSubscription> {
  const credential = getApp().options.credential;
  if (!credential) throw new Error("Google application credentials are unavailable.");
  const accessToken = await credential.getAccessToken();
  const settings = config();
  const url = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${encodeURIComponent(settings.packageName)}/purchases/subscriptionsv2/tokens/${encodeURIComponent(purchaseToken)}`;
  const response = await fetch(url, {headers: {Authorization: `Bearer ${accessToken.access_token}`}, signal: AbortSignal.timeout(20_000)});
  if (!response.ok) throw new Error(`Google Play verification failed with HTTP ${response.status}.`);
  return response.json() as Promise<GoogleSubscription>;
}

function subscriptionState(value: GoogleSubscription, expiryMillis: number) {
  const active = ["SUBSCRIPTION_STATE_ACTIVE", "SUBSCRIPTION_STATE_IN_GRACE_PERIOD", "SUBSCRIPTION_STATE_CANCELED"].includes(String(value.subscriptionState))
    && Number.isFinite(expiryMillis) && expiryMillis > Date.now();
  const cancelled = ["SUBSCRIPTION_STATE_CANCELED", "SUBSCRIPTION_STATE_EXPIRED"].includes(String(value.subscriptionState));
  return {active, status: active ? "active" as const : cancelled ? "cancelled" as const : "expired" as const};
}

async function persist(uid: string, purchaseToken: string, value: GoogleSubscription): Promise<void> {
  if (value.externalAccountIdentifiers?.obfuscatedExternalAccountId !== accountId(uid)) throw new Error("Google Play purchase belongs to another GetGo account.");
  const validItems = (value.lineItems ?? []).filter(item => item.productId && productIds.has(item.productId));
  if (!validItems.length) throw new Error("Unexpected Google Play product.");
  const latest = validItems.sort((left, right) => Date.parse(right.expiryTime ?? "") - Date.parse(left.expiryTime ?? ""))[0];
  const expiryMillis = Date.parse(latest.expiryTime ?? "");
  const expiresAt = Number.isFinite(expiryMillis) ? Timestamp.fromMillis(expiryMillis) : null;
  const state = subscriptionState(value, expiryMillis);
  const db = getFirestore(); const parentRef = db.doc(`getgo/${uid}`);
  await db.runTransaction(async tx => {
    const [parent, sourceSnapshot] = await Promise.all([tx.get(parentRef), tx.get(parentRef.collection("subscriptionSources"))]);
    const sources = subscriptionSources(sourceSnapshot, parent.data());
    applySubscriptionSource(tx, parentRef, sources, "google", {
      provider: "google", status: state.status, productId: latest.productId, expiresAt,
      autoRenewing: state.active && latest.autoRenewingPlan?.autoRenewEnabled === true,
      purchaseTokenHash: tokenId(purchaseToken), subscriptionState: value.subscriptionState,
    });
    tx.set(db.doc(`getgo-google-purchase-tokens/${tokenId(purchaseToken)}`), {uid, purchaseToken, updatedAt: Timestamp.now()}, {merge: true});
  });
}

export const syncGetGoGooglePlaySubscription = onCall({region: DEPLOYMENT_REGION, secrets: [configSecret]}, withCallableErrorDetails("Google Play subscription could not be verified.", async (request: CallableRequest<{purchases?: GooglePurchaseInput[]}>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const purchases = request.data?.purchases;
  if (!Array.isArray(purchases) || purchases.length < 1 || purchases.length > 4) throw new HttpsError("invalid-argument", "Google Play purchases are required.");
  const verified = await Promise.all(purchases.map(async item => ({item, value: await verify(String(item.purchaseToken))})));
  for (const result of verified) await persist(request.auth.uid, String(result.item.purchaseToken), result.value);
  const subscribed = verified.some(result => {
    const expiryMillis = Math.max(0, ...(result.value.lineItems ?? []).map(item => Date.parse(item.expiryTime ?? "") || 0));
    return subscriptionState(result.value, expiryMillis).active;
  });
  return {verified: true, subscribed};
}));

export const getGoGooglePlayNotifications = onRequest({region: DEPLOYMENT_REGION, secrets: [configSecret], invoker: "public"}, async (request, response) => {
  try {
    const encoded = request.body?.message?.data;
    const notification = typeof encoded === "string" ? JSON.parse(Buffer.from(encoded, "base64").toString("utf8")) as {subscriptionNotification?: {purchaseToken?: string}} : {};
    const purchaseToken = notification.subscriptionNotification?.purchaseToken;
    if (!purchaseToken) { response.status(200).send("OK"); return; }
    const mapping = await getFirestore().doc(`getgo-google-purchase-tokens/${tokenId(purchaseToken)}`).get();
    const uid = mapping.data()?.uid;
    if (typeof uid === "string" && uid) await persist(uid, purchaseToken, await verify(purchaseToken));
    response.status(200).send("OK");
  } catch (error) {
    console.error("[GetGo Google Play] notification verification failed", error);
    response.status(400).send("Invalid notification");
  }
});
