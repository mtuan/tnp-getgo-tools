import {getFirestore, Timestamp} from "firebase-admin/firestore";
import {HttpsError, onCall, type CallableRequest} from "firebase-functions/v2/https";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";
import {isAdminUser} from "../users/adminAuth.js";

const REVIEW_COLLECTION = "getgo-payment-reviews";
const REVIEW_NOTE_MAX = 1000;
const REVIEW_FEEDBACK_MAX = 2000;

const requireAuth = (request: CallableRequest<unknown>): string => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  return request.auth.uid;
};

async function requireAdmin(request: CallableRequest<unknown>): Promise<string> {
  const uid = requireAuth(request);
  const email = typeof request.auth?.token.email === "string" ? request.auth.token.email : undefined;
  if (!(await isAdminUser(uid, email))) throw new HttpsError("permission-denied", "GetGo administrator access is required.");
  return uid;
}

function requiredText(value: unknown, label: string, maxLength: number): string {
  if (typeof value !== "string" || !value.trim()) throw new HttpsError("invalid-argument", `${label} is required.`);
  const text = value.trim();
  if (text.length > maxLength) throw new HttpsError("invalid-argument", `${label} is too long.`);
  return text;
}

function optionalString(value: unknown): string | undefined {
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}

function iso(value: unknown): string | null {
  return value instanceof Timestamp ? value.toDate().toISOString() : null;
}

export function paymentReviewId(parentUid: string, paymentId: string): string {
  return `${parentUid}_${paymentId}`;
}

export function paymentReviewRef(parentUid: string, paymentId: string) {
  return getFirestore().collection(REVIEW_COLLECTION).doc(paymentReviewId(parentUid, paymentId));
}

function serializeReview(id: string, value: Record<string, unknown>) {
  return {
    id,
    paymentId: String(value.paymentId || ""), parentUid: String(value.parentUid || ""),
    parentName: String(value.parentName || ""), parentEmail: String(value.parentEmail || ""),
    transactionId: String(value.transactionId || ""), orderId: String(value.orderId || ""),
    providerTransactionId: String(value.providerTransactionId || ""), productId: String(value.productId || ""),
    productName: value.productName, amount: Number(value.amount || 0), currency: String(value.currency || "VND"),
    transferredAt: iso(value.transferredAt), reason: String(value.reason || "not-payable"),
    status: value.status === "resolved" ? "resolved" : "pending", note: String(value.note || ""),
    feedback: String(value.feedback || ""), requestedAt: iso(value.requestedAt), updatedAt: iso(value.updatedAt),
    resolvedAt: iso(value.resolvedAt), resolvedBy: optionalString(value.resolvedBy) ?? null,
  };
}

export const submitGetGoPaymentReview = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Payment review request could not be saved.", async (request: CallableRequest<{paymentId?: string; note?: string}>) => {
  const parentUid = requireAuth(request);
  const paymentId = requiredText(request.data?.paymentId, "Payment", 200);
  if (paymentId.includes("/")) throw new HttpsError("invalid-argument", "Invalid payment.");
  const note = requiredText(request.data?.note, "Review note", REVIEW_NOTE_MAX);
  const db = getFirestore(); const historyRef = db.doc(`getgo/${parentUid}/paymentHistory/${paymentId}`); const reviewRef = paymentReviewRef(parentUid, paymentId);
  const review = await db.runTransaction(async transaction => {
    const [historySnapshot, reviewSnapshot, parentSnapshot] = await transaction.getAll(historyRef, reviewRef, db.doc(`getgo/${parentUid}`));
    if (!historySnapshot.exists) throw new HttpsError("not-found", "Payment history entry was not found.");
    const payment = historySnapshot.data()!;
    if (payment.outcome !== "rejected" || !payment.providerTransactionId) throw new HttpsError("failed-precondition", "Only a confirmed transfer that did not grant access can be reviewed.");
    if (reviewSnapshot.data()?.status === "resolved") throw new HttpsError("failed-precondition", "This payment review has already been resolved.");
    const now = Timestamp.now(); const parent = parentSnapshot.data() ?? {};
    const data = {
      schemaVersion: 1, paymentId, parentUid, parentName: String(parent.name || ""), parentEmail: String(parent.email || request.auth?.token.email || ""),
      transactionId: String(payment.transactionId || ""), orderId: String(payment.orderId || ""), providerTransactionId: String(payment.providerTransactionId),
      productId: String(payment.productId || ""), productName: payment.productName, amount: Number(payment.amount || 0), currency: String(payment.currency || "VND"),
      transferredAt: payment.transferredAt, reason: String(payment.reason || "not-payable"), status: "pending", note, feedback: "",
      requestedAt: reviewSnapshot.data()?.requestedAt instanceof Timestamp ? reviewSnapshot.data()!.requestedAt : now,
      updatedAt: now, resolvedAt: null, resolvedBy: null,
    };
    transaction.set(reviewRef, data, {merge: true});
    transaction.set(historyRef, {reviewStatus: "pending", reviewUpdatedAt: now}, {merge: true});
    return data;
  });
  return {review: serializeReview(reviewRef.id, review)};
}));

export const adminListGetGoPaymentReviews = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Payment review requests could not be loaded.", async (request: CallableRequest<{cursor?: string; limit?: number}>) => {
  await requireAdmin(request);
  const limit = Math.max(1, Math.min(100, Math.trunc(Number(request.data?.limit) || 50)));
  let query = getFirestore().collection(REVIEW_COLLECTION).orderBy("updatedAt", "desc").limit(limit + 1);
  const cursor = optionalString(request.data?.cursor);
  if (cursor) { const date = new Date(cursor); if (!Number.isFinite(date.getTime())) throw new HttpsError("invalid-argument", "Invalid review cursor."); query = query.startAfter(Timestamp.fromDate(date)); }
  const snapshot = await query.get(); const page = snapshot.docs.slice(0, limit);
  return {items: page.map(doc => serializeReview(doc.id, doc.data())), nextCursor: snapshot.size > limit ? iso(page[page.length - 1]?.get("updatedAt")) : null};
}));

export const adminResolveGetGoPaymentReview = onCall({region: DEPLOYMENT_REGION}, withCallableErrorDetails("Payment review request could not be resolved.", async (request: CallableRequest<{reviewId?: string; feedback?: string}>) => {
  const adminUid = await requireAdmin(request);
  const reviewId = requiredText(request.data?.reviewId, "Review", 400);
  if (reviewId.includes("/")) throw new HttpsError("invalid-argument", "Invalid review.");
  const feedback = requiredText(request.data?.feedback, "Feedback", REVIEW_FEEDBACK_MAX);
  const db = getFirestore(); const reviewRef = db.collection(REVIEW_COLLECTION).doc(reviewId);
  const resolved = await db.runTransaction(async transaction => {
    const reviewSnapshot = await transaction.get(reviewRef);
    if (!reviewSnapshot.exists) throw new HttpsError("not-found", "Payment review request was not found.");
    const current = reviewSnapshot.data()!;
    if (current.status === "resolved") throw new HttpsError("failed-precondition", "Payment review request has already been resolved.");
    const now = Timestamp.now(); const data = {...current, status: "resolved", feedback, resolvedAt: now, resolvedBy: adminUid, updatedAt: now};
    transaction.set(reviewRef, {status: "resolved", feedback, resolvedAt: now, resolvedBy: adminUid, updatedAt: now}, {merge: true});
    const parentUid = String(current.parentUid || ""); const paymentId = String(current.paymentId || "");
    if (parentUid && paymentId) {
      transaction.set(db.doc(`getgo/${parentUid}/paymentHistory/${paymentId}`), {reviewStatus: "resolved", reviewUpdatedAt: now}, {merge: true});
      transaction.set(db.doc(`getgo/${parentUid}/notifications/payment-review-${paymentId}-resolved`), {
        schemaVersion: 1, kind: "payment", titleKey: "notifications.events.paymentReviewResolvedTitle",
        messageKey: "notifications.events.paymentReviewResolvedMessage", params: {orderId: String(current.orderId || "")},
        route: "/parent/subscribe", createdAt: now, readAt: null,
      });
    }
    return data;
  });
  return {review: serializeReview(reviewId, resolved)};
}));
