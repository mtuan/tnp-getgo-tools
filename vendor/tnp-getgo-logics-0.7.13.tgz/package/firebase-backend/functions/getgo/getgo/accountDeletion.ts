import {getAuth} from "firebase-admin/auth";
import {FieldPath, FieldValue, getFirestore, Query} from "firebase-admin/firestore";
import {getStorage} from "firebase-admin/storage";
import * as logger from "firebase-functions/logger";
import {HttpsError, onCall, type CallableRequest} from "firebase-functions/v2/https";
import {callableError, withCallableErrorDetails} from "../callableError.js";
import {isAdminUser} from "../users/adminAuth.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";

async function deleteQuery(query: Query): Promise<number> {
  const snapshot = await query.get();
  if (snapshot.empty) return 0;
  const writer = getFirestore().bulkWriter();
  snapshot.docs.forEach((item) => writer.delete(item.ref));
  await writer.close();
  return snapshot.size;
}

async function deleteStudentLeaderboardData(uid: string, studentId: string): Promise<number> {
  const firestore = getFirestore();
  const [entries, receipts] = await Promise.all([
    firestore.collectionGroup("starEntries").where("parentId", "==", uid).get(),
    firestore.collection("getgo-leaderboard-awards").where("parentId", "==", uid).get(),
  ]);
  const matches = [...entries.docs, ...receipts.docs]
    .filter((item) => item.get("studentId") === studentId);
  if (!matches.length) return 0;
  const writer = firestore.bulkWriter();
  matches.forEach((item) => writer.delete(item.ref));
  await writer.close();
  return matches.length;
}

async function deleteMarketplaceActivity(uid: string): Promise<{
  reviews: number;
  topics: number;
}> {
  const firestore = getFirestore();
  const topics = await firestore.collection("getgo-marketplace-topics").listDocuments();
  let reviews = 0;
  let parentTopics = 0;
  await Promise.all(topics.map(async (topic) => {
    const review = topic.collection("reviews").doc(uid);
    const user = topic.collection("users").doc(uid);
    const [reviewSnapshot, removedTopic] = await Promise.all([
      review.get(),
      firestore.runTransaction(async (transaction) => {
        const [marker, summary] = await transaction.getAll(user, topic);
        if (!marker.exists) return false;
        transaction.delete(user);
        transaction.set(topic, {
          userCount: Math.max(0, Number(summary.data()?.userCount ?? 0) - 1),
        }, {merge: true});
        return true;
      }),
    ]);
    if (removedTopic) parentTopics += 1;
    if (reviewSnapshot.exists) {
      await review.delete();
      reviews += 1;
    }
  }));
  return {reviews, topics: parentTopics};
}

async function deleteGetGoData(uid: string, preserveParentProfile: boolean) {
  const firestore = getFirestore();
  const parent = firestore.doc(`getgo/${uid}`);
  const parentSnapshot = preserveParentProfile ? await parent.get() : null;
  const [marketplace, reports, aiUsage, leaderboardAwards, starEntries] = await Promise.all([
    deleteMarketplaceActivity(uid),
    deleteQuery(firestore.collection("question-reports").where("reportedBy", "==", uid)),
    deleteQuery(firestore.collection("getgo-ai-usage").where("uid", "==", uid)),
    deleteQuery(firestore.collection("getgo-leaderboard-awards").where("parentId", "==", uid)),
    deleteQuery(firestore.collectionGroup("starEntries").where("parentId", "==", uid)),
    firestore.recursiveDelete(parent),
    preserveParentProfile
      ? getStorage().bucket().deleteFiles({prefix: `getgo/${uid}/students/`, force: true})
      : getStorage().bucket().deleteFiles({prefix: `getgo/${uid}/`, force: true}),
  ]);
  if (parentSnapshot?.exists) await parent.set(parentSnapshot.data()!);
  return {marketplace, reports, aiUsage, leaderboardAwards, starEntries};
}

async function deleteAuthUserIfPresent(uid: string): Promise<boolean> {
  try {
    await getAuth().deleteUser(uid);
    return true;
  } catch (error) {
    if ((error as {code?: string}).code === "auth/user-not-found") return false;
    throw error;
  }
}

async function mergeDocumentTree(source: FirebaseFirestore.DocumentReference, target: FirebaseFirestore.DocumentReference): Promise<void> {
  const [sourceSnapshot, targetSnapshot, collections] = await Promise.all([
    source.get(),
    target.get(),
    source.listCollections(),
  ]);
  if (sourceSnapshot.exists) {
    await target.set({...sourceSnapshot.data(), ...(targetSnapshot.data() ?? {})}, {merge: true});
  }
  for (const sourceCollection of collections) {
    const documents = await sourceCollection.listDocuments();
    await Promise.all(documents.map((document) =>
      mergeDocumentTree(document, target.collection(sourceCollection.id).doc(document.id))));
  }
}

async function reassignQuery(query: Query, fieldName: string, uid: string): Promise<number> {
  const snapshot = await query.get();
  if (snapshot.empty) return 0;
  const writer = getFirestore().bulkWriter();
  snapshot.docs.forEach((item) => writer.update(item.ref, {[fieldName]: uid}));
  await writer.close();
  return snapshot.size;
}

async function mergeMarketplaceIdentity(sourceUid: string, targetUid: string): Promise<void> {
  const firestore = getFirestore();
  const topics = await firestore.collection("getgo-marketplace-topics").listDocuments();
  await Promise.all(topics.map((topic) => firestore.runTransaction(async (transaction) => {
    const sourceReview = topic.collection("reviews").doc(sourceUid);
    const targetReview = topic.collection("reviews").doc(targetUid);
    const sourceUser = topic.collection("users").doc(sourceUid);
    const targetUser = topic.collection("users").doc(targetUid);
    const [sourceReviewSnapshot, targetReviewSnapshot, sourceUserSnapshot, targetUserSnapshot, topicSnapshot] =
      await transaction.getAll(sourceReview, targetReview, sourceUser, targetUser, topic);
    if (sourceReviewSnapshot.exists) {
      if (!targetReviewSnapshot.exists) transaction.set(targetReview, {...sourceReviewSnapshot.data(), parentId: targetUid});
      else transaction.set(topic, {
        ratingCount: Math.max(0, Number(topicSnapshot.data()?.ratingCount ?? 0) - 1),
        ratingTotal: Math.max(0, Number(topicSnapshot.data()?.ratingTotal ?? 0) - Number(sourceReviewSnapshot.get("rating") ?? 0)),
      }, {merge: true});
      transaction.delete(sourceReview);
    }
    if (sourceUserSnapshot.exists) {
      if (!targetUserSnapshot.exists) transaction.set(targetUser, {...sourceUserSnapshot.data(), parentId: targetUid});
      else transaction.set(topic, {userCount: Math.max(0, Number(topicSnapshot.data()?.userCount ?? 0) - 1)}, {merge: true});
      transaction.delete(sourceUser);
    }
  })));
}

async function mergeStorageIdentity(sourceUid: string, targetUid: string): Promise<void> {
  const bucket = getStorage().bucket();
  const [files] = await bucket.getFiles({prefix: `getgo/${sourceUid}/`});
  for (const file of files) {
    const destinationName = file.name.replace(`getgo/${sourceUid}/`, `getgo/${targetUid}/`);
    const destination = bucket.file(destinationName);
    const [exists] = await destination.exists();
    if (!exists) await file.copy(destination);
    await file.delete({ignoreNotFound: true});
  }
}

async function mergeOrphanedGetGoProfile(sourceUid: string, targetUid: string, targetEmail: string): Promise<void> {
  const firestore = getFirestore();
  const source = firestore.doc(`getgo/${sourceUid}`);
  const target = firestore.doc(`getgo/${targetUid}`);
  const [sourceSnapshot, targetSnapshot] = await Promise.all([source.get(), target.get()]);
  await mergeDocumentTree(source, target);
  const sourceData = sourceSnapshot.data() ?? {};
  const targetData = targetSnapshot.data() ?? {};
  const tierRank = (value: unknown) => value === "admin" ? 2 : value === "premium" ? 1 : 0;
  const preserveSourceMembership = tierRank(sourceData.packageId) > tierRank(targetData.packageId);
  await target.set({
    id: targetUid,
    email: targetEmail,
    ...(preserveSourceMembership ? {
      packageId: sourceData.packageId,
      subscriptionStartsAt: sourceData.subscriptionStartsAt ?? null,
      subscriptionExpiresAt: sourceData.subscriptionExpiresAt ?? null,
      subscriptionGrantedAt: sourceData.subscriptionGrantedAt ?? null,
      isAdFree: sourceData.isAdFree ?? true,
      adFreeUpdatedAt: sourceData.adFreeUpdatedAt ?? FieldValue.serverTimestamp(),
    } : {}),
    updatedAt: FieldValue.serverTimestamp(),
  }, {merge: true});
  await Promise.all([
    reassignQuery(firestore.collection("question-reports").where("reportedBy", "==", sourceUid), "reportedBy", targetUid),
    reassignQuery(firestore.collection("getgo-ai-usage").where("uid", "==", sourceUid), "uid", targetUid),
    reassignQuery(firestore.collection("getgo-leaderboard-awards").where("parentId", "==", sourceUid), "parentId", targetUid),
    reassignQuery(firestore.collectionGroup("starEntries").where("parentId", "==", sourceUid), "parentId", targetUid),
    mergeMarketplaceIdentity(sourceUid, targetUid),
    mergeStorageIdentity(sourceUid, targetUid),
  ]);
  await Promise.all([
    firestore.recursiveDelete(firestore.doc(`getgo/${sourceUid}`)),
    firestore.recursiveDelete(firestore.doc(`users/${sourceUid}`)),
  ]);
}

export const reconcileGetGoWebAccount = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 540,
  memory: "1GiB",
}, withCallableErrorDetails("Account reconciliation could not be completed.", async (request: CallableRequest<unknown>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const uid = request.auth.uid;
  const authenticatedUser = await getAuth().getUser(uid);
  const email = authenticatedUser.email?.trim().toLocaleLowerCase();
  if (!email) return {mergedProfileCount: 0};
  const candidates = await getFirestore().collection("getgo").where("email", "==", email).get();
  const sourceIds: string[] = [];
  for (const candidate of candidates.docs) {
    if (candidate.id === uid) continue;
    try {
      await getAuth().getUser(candidate.id);
    } catch (error) {
      if ((error as {code?: string}).code !== "auth/user-not-found") throw error;
      sourceIds.push(candidate.id);
    }
  }
  for (const sourceUid of sourceIds) await mergeOrphanedGetGoProfile(sourceUid, uid, email);
  logger.info("GetGo account reconciliation completed", {uid, mergedProfileCount: sourceIds.length});
  return {mergedProfileCount: sourceIds.length};
}));

export const clearGetGoWebData = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 540,
  memory: "1GiB",
}, withCallableErrorDetails("Data deletion could not be completed.", async (request: CallableRequest<unknown>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const uid = request.auth.uid;
  logger.info("GetGo data deletion started", {uid});
  try {
    const deleted = await deleteGetGoData(uid, true);
    logger.info("GetGo data deletion completed", {uid, deleted});
    return {cleared: true};
  } catch (error) {
    logger.error("GetGo data deletion failed", {uid, error});
    throw callableError("internal", "Data deletion could not be completed. Please try again.", error);
  }
}));

/**
 * Permanently deletes the calling GetGo account and all known personal data.
 * Authentication is deleted last so a failed cleanup can be safely retried.
 */
export const deleteGetGoWebAccount = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 540,
  memory: "1GiB",
}, withCallableErrorDetails("Account deletion could not be completed.", async (request: CallableRequest<unknown>) => {
  if (!request.auth) {
    throw new HttpsError("unauthenticated", "Authentication is required.");
  }
  const uid = request.auth.uid;
  logger.info("GetGo account deletion started", {uid});
  try {
    const deleted = await deleteGetGoData(uid, false);
    await getFirestore().recursiveDelete(getFirestore().doc(`users/${uid}`));

    await deleteAuthUserIfPresent(uid);
    logger.info("GetGo account deletion completed", {uid, deleted});
    return {deleted: true};
  } catch (error) {
    logger.error("GetGo account deletion failed", {uid, error});
    throw callableError(
      "internal",
      "Account deletion could not be completed. Please try again.",
      error
    );
  }
}));

export const adminDeleteGetGoMember = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 540,
  memory: "1GiB",
}, withCallableErrorDetails("Member deletion could not be completed.", async (request: CallableRequest<{memberId?: string}>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  if (!(await isAdminUser(request.auth.uid, typeof request.auth.token.email === "string" ? request.auth.token.email : undefined))) {
    throw new HttpsError("permission-denied", "Admin access required.");
  }
  const memberId = requiredIdentifier(request.data?.memberId, "memberId");
  if (memberId === request.auth.uid) {
    throw new HttpsError("failed-precondition", "Use self-service account deletion to delete your own account.");
  }
  const firestore = getFirestore();
  const profile = await firestore.doc(`getgo/${memberId}`).get();
  if (!profile.exists) throw new HttpsError("not-found", "Member profile does not exist.");
  logger.info("Administrative GetGo member deletion started", {memberId, changedByUid: request.auth.uid});
  await firestore.collection("getgo-admin-audit").add({
    action: "member-permanent-deletion-started",
    memberId,
    memberEmail: profile.get("email") ?? null,
    memberName: profile.get("name") ?? null,
    changedByUid: request.auth.uid,
    changedByEmail: request.auth.token.email ?? null,
    changedAt: FieldValue.serverTimestamp(),
  });
  const deleted = await deleteGetGoData(memberId, false);
  await firestore.recursiveDelete(firestore.doc(`users/${memberId}`));
  // Authentication is intentionally the final mutation so failed cleanup can
  // be retried while the member identity still exists.
  const authenticationDeleted = await deleteAuthUserIfPresent(memberId);
  logger.info("Administrative GetGo member deletion completed", {memberId, changedByUid: request.auth.uid, authenticationDeleted, deleted});
  return {deleted: true, authenticationDeleted};
}));

type StudentDataOperation = "clear_all" | "clear_topic" | "reset" | "delete";

function requiredIdentifier(value: unknown, label: string): string {
  if (typeof value !== "string" || !value || value.length > 200 || value.includes("/")) {
    throw new HttpsError("invalid-argument", `A valid ${label} is required.`);
  }
  return value;
}

export const manageGetGoWebStudentData = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 540,
  memory: "1GiB",
}, withCallableErrorDetails("Student data could not be updated.", async (request: CallableRequest<{
  studentId?: string;
  topicId?: string;
  operation?: StudentDataOperation;
}>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const uid = request.auth.uid;
  const studentId = requiredIdentifier(request.data?.studentId, "studentId");
  const operation = request.data?.operation;
  if (operation !== "clear_all" && operation !== "clear_topic" && operation !== "reset" && operation !== "delete") {
    throw new HttpsError("invalid-argument", "A valid operation is required.");
  }
  const firestore = getFirestore();
  const student = firestore.doc(`getgo/${uid}/students/${studentId}`);
  if (!(await student.get()).exists) throw new HttpsError("not-found", "Student does not exist.");

  if (operation === "clear_topic") {
    const topicId = requiredIdentifier(request.data?.topicId, "topicId");
    await Promise.all([
      deleteQuery(student.collection("tests").where("topicId", "==", topicId)),
      firestore.recursiveDelete(student.collection("progress").doc(topicId)),
      student.update(
        new FieldPath("learnedQuizIdsByTopic", topicId),
        FieldValue.delete(),
      ),
    ]);
    return {completed: true};
  }

  if (operation === "clear_all" || operation === "reset") {
    await Promise.all([
      firestore.recursiveDelete(student.collection("tests")),
      firestore.recursiveDelete(student.collection("dailyTracking")),
      firestore.recursiveDelete(student.collection("weeklyTracking")),
      firestore.recursiveDelete(student.collection("progress")),
      ...(operation === "reset" ? [deleteStudentLeaderboardData(uid, studentId)] : []),
    ]);
    await student.set({
      learnedQuizIdsByTopic: {},
      ...(operation === "reset" ? {totalStars: 0, starsByTopic: {}, weeklyStars: null} : {}),
    }, {merge: true});
    return {completed: true};
  }

  await Promise.all([
    firestore.recursiveDelete(student),
    deleteStudentLeaderboardData(uid, studentId),
    getStorage().bucket().deleteFiles({prefix: `getgo/${uid}/avatars/${studentId}.`, force: true}),
  ]);
  return {completed: true};
}));
