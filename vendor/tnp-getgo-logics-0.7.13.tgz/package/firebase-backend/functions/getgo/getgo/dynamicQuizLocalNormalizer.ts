import type {
  DynamicQuestionProposal,
} from "./dynamicQuestionProposal.js";

export type DynamicQuizQuestionProposal =
  Omit<DynamicQuestionProposal, "explanationGeneratorTs"> & {
    explanationGeneratorTs?: string;
  };

export interface LocalDynamicQuizProposalItem {
  questionIndex: number;
  questionNo: number;
  generationMode: "local-image";
  proposal: DynamicQuizQuestionProposal;
}

function isImageReference(value: unknown): boolean {
  return typeof value === "string" && (
    /^asset:/i.test(value) ||
    /^data:image\//i.test(value) ||
    /\.(?:png|jpe?g|gif|webp|svg)(?:[?#]|$)/i.test(value)
  );
}

export function questionContainsImages(
  question: Record<string, unknown>
): boolean {
  if (
    Array.isArray(question.image_datas) &&
    question.image_datas.length > 0
  ) {
    return true;
  }
  const answer = question.answer as Record<string, unknown> | undefined;
  const choices = answer?.choices as Record<string, unknown> | undefined;
  return Object.values(choices ?? {}).some(isImageReference);
}

function sourceLiteral(value: unknown): string {
  return JSON.stringify(value, null, 2).replace(
    /^(\s*)"([A-Za-z_$][\w$]*)":/gm,
    "$1$2:"
  );
}

function indent(source: string, spaces: number): string {
  const prefix = " ".repeat(spaces);
  return source.split("\n").map((line) => `${prefix}${line}`).join("\n");
}

function numericValue(value: unknown): unknown {
  if (
    typeof value === "string" &&
    /^-?(?:\d+|\d*\.\d+)$/.test(value.trim())
  ) {
    return Number(value);
  }
  return value;
}

function normalizedChoiceValues(values: unknown[]): {
  values: unknown[];
  unit?: string;
} {
  const parsed = values.map((value) =>
    typeof value === "string" ?
      value.trim().match(/^(-?(?:\d+|\d*\.\d+))\s+(.+)$/) :
      null
  );
  if (parsed.every(Boolean)) {
    const units = parsed.map((match) => match?.[2].trim());
    if (units.every((unit) => unit === units[0])) {
      return {
        values: parsed.map((match) => Number(match?.[1])),
        unit: units[0],
      };
    }
  }
  return {values: values.map(numericValue)};
}

function answerExpression(answerValue: unknown): string {
  const answer =
    answerValue && typeof answerValue === "object" ?
      answerValue as Record<string, unknown> :
      {};
  const choices =
    answer.choices && typeof answer.choices === "object" ?
      answer.choices as Record<string, unknown> :
      undefined;
  const correct = answer.correct;
  if (choices && Object.keys(choices).length > 0) {
    if (Object.values(choices).some(isImageReference)) {
      return `QB.answer.choice(${sourceLiteral(correct)}, ` +
        `${sourceLiteral(choices)})`;
    }
    const normalized = normalizedChoiceValues(Object.values(choices));
    const core = `QB.answer.choice(${sourceLiteral(correct)}, ` +
      `${sourceLiteral(normalized.values)})`;
    return normalized.unit ?
      `QB.answer.extend(\n${indent(core, 2)},\n` +
        `  { unit: ${sourceLiteral(normalized.unit)} },\n)` :
      core;
  }
  const normalized = normalizedChoiceValues([correct]);
  const core = `QB.answer.input(${sourceLiteral(normalized.values[0])})`;
  return normalized.unit ?
    `QB.answer.extend(\n${indent(core, 2)},\n` +
      `  { unit: ${sourceLiteral(normalized.unit)} },\n)` :
    core;
}

function questionGeneratorSource(
  question: Record<string, unknown>
): string {
  const fields = Object.fromEntries(
    Object.entries(question).filter(([key, value]) =>
      key !== "answer" &&
      key !== "verified" &&
      key !== "schemaVersion" &&
      key !== "authoringMode" &&
      key !== "advancedDynamic" &&
      key !== "generatorBuild" &&
      !(key === "text_vn" && value === "")
    )
  );
  const fieldSource = sourceLiteral(fields).slice(1, -1).trim();
  const answer = answerExpression(question.answer);
  return `({}) => {\n  return {\n` +
    `${fieldSource ? `${indent(fieldSource, 4)},\n` : ""}` +
    `    answer: ${indent(answer, 4).trimStart()},\n` +
    `  }\n}`;
}

export function normalizeImageQuestionLocally(
  question: Record<string, unknown>,
  questionIndex: number
): LocalDynamicQuizProposalItem {
  return {
    questionIndex,
    questionNo: Number(question.question_no),
    generationMode: "local-image",
    proposal: {
      paramsGeneratorTs: "() => {\n  return {}\n}",
      questionGeneratorTs: questionGeneratorSource(question),
      originParamsTs: "{}",
      parameterizedValues: [],
      explanation: "Static image question normalized locally without AI.",
      assumptions: [],
      warnings: [],
      confidence: 1,
    },
  };
}

export function partitionDynamicQuizQuestions(
  questions: Record<string, unknown>[]
): {
  aiQuestions: Array<{
    question: Record<string, unknown>;
    questionIndex: number;
  }>;
  localItems: LocalDynamicQuizProposalItem[];
} {
  const indexed = questions.map(
    (question, questionIndex) => ({question, questionIndex})
  );
  return {
    aiQuestions: indexed.filter(
      ({question}) => !questionContainsImages(question)
    ),
    localItems: indexed
      .filter(({question}) => questionContainsImages(question))
      .map(({question, questionIndex}) =>
        normalizeImageQuestionLocally(question, questionIndex)
      ),
  };
}
