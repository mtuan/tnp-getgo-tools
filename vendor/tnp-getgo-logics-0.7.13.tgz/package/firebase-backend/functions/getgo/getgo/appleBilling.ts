import {createHash} from "node:crypto";
import {Environment, SignedDataVerifier, type JWSTransactionDecodedPayload} from "@apple/app-store-server-library";
import {FieldValue, getFirestore, Timestamp} from "firebase-admin/firestore";
import {defineSecret} from "firebase-functions/params";
import {HttpsError, onCall, onRequest, type CallableRequest} from "firebase-functions/v2/https";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";

interface AppleIapConfig {bundleId: string; appAppleId: number}

const configSecret = defineSecret("GETGO_APPLE_IAP_CONFIG");
const productIds = new Set(["com.tnp.getgo.premium.monthly", "com.tnp.getgo.premium.annual"]);
const roots = [
  "MIIFkjCCA3qgAwIBAgIIAeDltYNno+AwDQYJKoZIhvcNAQEMBQAwZzEbMBkGA1UEAwwSQXBwbGUgUm9vdCBDQSAtIEcyMSYwJAYDVQQLDB1BcHBsZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTETMBEGA1UECgwKQXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwHhcNMTQwNDMwMTgxMDA5WhcNMzkwNDMwMTgxMDA5WjBnMRswGQYDVQQDDBJBcHBsZSBSb290IENBIC0gRzIxJjAkBgNVBAsMHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBANgREkhI2imKScUcx+xuM23+TfvgHN6sXuI2pyT5f1BrTM65MFQn5bPW7SXmMLYFN14UIhHF6Kob0vuy0gmVOKTvKkmMXT5xZgM4+xb1hYjkWpIMBDLyyED7Ul+f9sDx47pFoFDVEovy3d6RhiPw9bZyLgHaC/YuOQhfGaFjQQscp5TBhsRTL3b2CtcM0YM/GlMZ81fVJ3/8E7j4ko380yhDPLVoACVdJ2LT3VXdRCCQgzWTxb+4Gftr49wIQuavbfqeQMpOhYV4SbHXw8EwOTKrfl+q04tvny0aIWhwZ7Oj8ZhBbZF8+NfbqOdfIRqMM78xdLe40fTgIvS/cjTf94FNcX1RoeKz8NMoFnNvzcytN31O661A4T+B/fc9Cj6i8b0xlilZ3MIZgIxbdMYs0xBTJh0UT8TUgWY8h2czJxQI6bR3hDRSj4n4aJgXv8O7qhOTH11UL6jHfPsNFL4VPSQ08prcdUFmIrQB1guvkJ4M6mL4m1k8COKWNORj3rw31OsMiANDC1CvoDTdUE0V+1ok2Az6DGOeHwOx4e7hqkP0ZmUoNwIx7wHHHtHMn23KVDpA287PT0aLSmWaasZobNfMmRtHsHLDd4/E92GcdB/O/WuhwpyUgquUoue9G7q5cDmVF8Up8zlYNPXEpMZ7YLlmQ1A/bmH8DvmGqmAMQ0uVAgMBAAGjQjBAMB0GA1UdDgQWBBTEmRNsGAPCe8CjoA1/coB6HHcmjTAPBgNVHRMBAf8EBTADAQH/MA4GA1UdDwEB/wQEAwIBBjANBgkqhkiG9w0BAQwFAAOCAgEAUabz4vS4PZO/Lc4Pu1vhVRROTtHlznldgX/+tvCHM/jvlOV+3Gp5pxy+8JS3ptEwnMgNCnWefZKVfhidfsJxaXwU6s+DDuQUQp50DhDNqxq6EWGBeNjxtUVAeKuowM77fWM3aPbn+6/Gw0vsHzYmE1SGlHKy6gLti23kDKaQwFd1z4xCfVzmMX3zybKSaUYOiPjjLUKyOKimGY3xn83uamW8GrAlvacp/fQ+onVJv57byfenHmOZ4VxG/5IFjPoeIPmGlFYl5bRXOJ3riGQUIUkhOb9iZqmxospvPyFgxYnURTbImHy99v6ZSYA7LNKmp4gDBDEZt7Y6YUX6yfIjyGNzv1aJMbDZfGKnexWoiIqrOEDCzBL/FePwN983csvMmOa/orz6JopxVtfnJBtIRD6e/J/JzBrsQzwBvDR4yGn1xuZW7AYJNpDrFEobXsmII9oDMJELuDY++ee1KG++P+w8j2Ud5cAeh6Squpj9kuNsJnfdBrRkBof0Tta6SqoWqPQFZ2aWuuJVecMsXUmPgEkrihLHdoBR37q9ZV0+N0djMenl9MU/S60EinpxLK8JQzcPqOMyT/RFtm2XNuyE9QoB6he7hY1Ck3DDUOUUi78/w0EP3SIEIwiKum1xRKtzCTrJ+VKACd+66eYWyi4uTLLT3OUEVLLUNIAytbwPF+E=",
  "MIICQzCCAcmgAwIBAgIILcX8iNLFS5UwCgYIKoZIzj0EAwMwZzEbMBkGA1UEAwwSQXBwbGUgUm9vdCBDQSAtIEczMSYwJAYDVQQLDB1BcHBsZSBDZXJ0aWZpY2F0aW9uIEF1dGhvcml0eTETMBEGA1UECgwKQXBwbGUgSW5jLjELMAkGA1UEBhMCVVMwHhcNMTQwNDMwMTgxOTA2WhcNMzkwNDMwMTgxOTA2WjBnMRswGQYDVQQDDBJBcHBsZSBSb290IENBIC0gRzMxJjAkBgNVBAsMHUFwcGxlIENlcnRpZmljYXRpb24gQXV0aG9yaXR5MRMwEQYDVQQKDApBcHBsZSBJbmMuMQswCQYDVQQGEwJVUzB2MBAGByqGSM49AgEGBSuBBAAiA2IABJjpLz1AcqTtkyJygRMc3RCV8cWjTnHcFBbZDuWmBSp3ZHtfTjjTuxxEtX/1H7YyYl3J6YRbTzBPEVoA/VhYDKX1DyxNB0cTddqXl5dvMVztK517IDvYuVTZXpmkOlEKMaNCMEAwHQYDVR0OBBYEFLuw3qFYM4iapIqZ3r6966/ayySrMA8GA1UdEwEB/wQFMAMBAf8wDgYDVR0PAQH/BAQDAgEGMAoGCCqGSM49BAMDA2gAMGUCMQCD6cHEFl4aXTQY2e3v9GwOAEZLuN+yRhHFD/3meoyhpmvOwgPUnPWTxnS4at+qIxUCMG1mihDK1A3UT82NQz60imOlM27jbdoXt2QfyFMm+YhidDkLF1vLUagM6BgD56KyKA==",
].map(value => Buffer.from(value, "base64"));

function config(): AppleIapConfig {
  const value = JSON.parse(configSecret.value()) as Partial<AppleIapConfig>;
  if (!value.bundleId || !Number.isSafeInteger(value.appAppleId)) throw new Error("GETGO_APPLE_IAP_CONFIG requires bundleId and numeric appAppleId.");
  return value as AppleIapConfig;
}

function unverifiedEnvironment(jws: string): Environment {
  try {
    const payload = JSON.parse(Buffer.from(jws.split(".")[1], "base64url").toString("utf8")) as {environment?: string; data?: {environment?: string}};
    return (payload.environment ?? payload.data?.environment) === "Production" ? Environment.PRODUCTION : Environment.SANDBOX;
  } catch { throw new HttpsError("invalid-argument", "Invalid Apple transaction payload."); }
}

async function verifyTransaction(jws: string): Promise<JWSTransactionDecodedPayload> {
  const settings = config();
  const environment = unverifiedEnvironment(jws);
  const verifier = new SignedDataVerifier(roots, true, environment, settings.bundleId, environment === Environment.PRODUCTION ? settings.appAppleId : undefined);
  const transaction = await verifier.verifyAndDecodeTransaction(jws);
  if (!transaction.productId || !productIds.has(transaction.productId)) throw new Error("Unexpected Apple product.");
  return transaction;
}

function accountToken(uid: string): string {
  const bytes = Buffer.from(createHash("sha256").update(uid).digest().subarray(0, 16));
  bytes[6] = (bytes[6] & 0x0f) | 0x50;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = bytes.toString("hex");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

async function persist(uid: string, transaction: JWSTransactionDecodedPayload, allowProviderSwitch: boolean): Promise<void> {
  if (!transaction.transactionId || !transaction.originalTransactionId || !transaction.productId) throw new Error("Apple transaction identifiers are missing.");
  if (transaction.appAccountToken?.toLowerCase() !== accountToken(uid)) throw new Error("Apple transaction belongs to another GetGo account.");
  const expiresAt = transaction.expiresDate ? Timestamp.fromMillis(transaction.expiresDate) : null;
  const active = !transaction.revocationDate && (!transaction.expiresDate || transaction.expiresDate > Date.now());
  const db = getFirestore();
  const parentRef = db.doc(`getgo/${uid}`);
  const transactionRef = db.doc(`getgo/${uid}/appleTransactions/${transaction.transactionId}`);
  await db.runTransaction(async tx => {
    const parent = (await tx.get(parentRef)).data();
    tx.set(transactionRef, {provider: "apple", productId: transaction.productId, originalTransactionId: transaction.originalTransactionId, transactionId: transaction.transactionId, appAccountToken: transaction.appAccountToken, environment: transaction.environment, purchaseDate: transaction.purchaseDate ? Timestamp.fromMillis(transaction.purchaseDate) : null, expiresAt, revokedAt: transaction.revocationDate ? Timestamp.fromMillis(transaction.revocationDate) : null, active, updatedAt: FieldValue.serverTimestamp()}, {merge: true});
    tx.set(db.doc(`getgo-apple-account-tokens/${accountToken(uid)}`), {uid, updatedAt: FieldValue.serverTimestamp()}, {merge: true});
    const currentExpiry = parent?.subscriptionExpiresAt instanceof Timestamp ? parent.subscriptionExpiresAt.toMillis() : 0;
    const incomingExpiry = transaction.expiresDate ?? Number.MAX_SAFE_INTEGER;
    if (active && (allowProviderSwitch || parent?.subscriptionProvider === "apple") && incomingExpiry >= currentExpiry) {
      tx.set(parentRef, {packageId: "premium", subscriptionProvider: "apple", subscriptionPaymentMethod: "iap", subscriptionProductId: transaction.productId, subscriptionTransactionId: transaction.transactionId, subscriptionOriginalTransactionId: transaction.originalTransactionId, subscriptionExpiresAt: expiresAt, subscriptionGrantedAt: FieldValue.serverTimestamp(), adfree: true}, {merge: true});
    } else {
      if (!active && parent?.subscriptionProvider === "apple" && parent.subscriptionOriginalTransactionId === transaction.originalTransactionId && incomingExpiry >= currentExpiry) {
        tx.set(parentRef, {packageId: "free", subscriptionExpiresAt: expiresAt ?? Timestamp.now(), subscriptionRevokedAt: transaction.revocationDate ? Timestamp.fromMillis(transaction.revocationDate) : FieldValue.serverTimestamp(), adfree: false}, {merge: true});
      }
    }
  });
}

export const syncGetGoAppleSubscription = onCall({region: DEPLOYMENT_REGION, secrets: [configSecret]}, withCallableErrorDetails("Apple subscription could not be verified.", async (request: CallableRequest<{signedTransactions?: string[]}>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const signedTransactions = request.data?.signedTransactions;
  if (!Array.isArray(signedTransactions) || signedTransactions.length < 1 || signedTransactions.length > 4) throw new HttpsError("invalid-argument", "Apple signed transactions are required.");
  const verified = await Promise.all(signedTransactions.map(value => verifyTransaction(String(value))));
  for (const transaction of verified) await persist(request.auth.uid, transaction, true);
  const latestExpiry = Math.max(0, ...verified.map(item => item.expiresDate ?? 0));
  return {verified: true, subscribed: verified.some(item => !item.revocationDate && (!item.expiresDate || item.expiresDate > Date.now())), expiresAt: latestExpiry ? new Date(latestExpiry).toISOString() : null};
}));

export const getGoAppleServerNotifications = onRequest({region: DEPLOYMENT_REGION, secrets: [configSecret], invoker: "public"}, async (request, response) => {
  try {
    const signedPayload = typeof request.body?.signedPayload === "string" ? request.body.signedPayload : "";
    if (!signedPayload) { response.status(400).send("Missing signedPayload"); return; }
    const settings = config();
    const environment = unverifiedEnvironment(signedPayload);
    const verifier = new SignedDataVerifier(roots, true, environment, settings.bundleId, environment === Environment.PRODUCTION ? settings.appAppleId : undefined);
    const notification = await verifier.verifyAndDecodeNotification(signedPayload);
    const signedTransaction = notification.data?.signedTransactionInfo;
    if (!signedTransaction) { response.status(200).send("OK"); return; }
    const transaction = await verifyTransaction(signedTransaction);
    if (!transaction.appAccountToken) { response.status(200).send("OK"); return; }
    const tokenSnapshot = await getFirestore().doc(`getgo-apple-account-tokens/${transaction.appAccountToken.toLowerCase()}`).get();
    const uid = tokenSnapshot.data()?.uid;
    if (typeof uid === "string" && uid) await persist(uid, transaction, false);
    response.status(200).send("OK");
  } catch (error) {
    console.error("[GetGo Apple IAP] notification verification failed", error);
    response.status(400).send("Invalid notification");
  }
});
