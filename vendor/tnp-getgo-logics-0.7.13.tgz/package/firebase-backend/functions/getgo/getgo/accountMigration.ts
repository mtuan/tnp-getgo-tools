import {getAuth} from "firebase-admin/auth";
import {FieldValue, Timestamp, getFirestore} from "firebase-admin/firestore";
import * as logger from "firebase-functions/logger";
import {HttpsError, onCall, type CallableRequest} from "firebase-functions/v2/https";
import {withCallableErrorDetails} from "../callableError.js";
import {DEPLOYMENT_REGION} from "../deploymentConfig.js";

const MIGRATION_VERSION = 2;
const TOUR_VERSION = 1;
const LEASE_DURATION_MS = 5 * 60 * 1000;

type MigrationAction = "resolve" | "status" | "update-tour" | "complete-tour" | "apply-registration-events";
type PremiumPreviewUserType = "new-registration" | "legacy-migration";
type RegistrationPlatform = "web" | "ios" | "android";

interface PremiumPreviewEvent {
  id: string;
  type: "premium-preview";
  recurrence: "one-time" | "yearly";
  startsOn: string;
  endsOn: string;
  enabled: boolean;
  premiumDays: number;
  targets: {userTypes: PremiumPreviewUserType[]; platforms?: RegistrationPlatform[]};
}

interface MigrationRequest {
  action?: MigrationAction;
  platform?: RegistrationPlatform;
  tourStep?: number;
}

interface LearnerSummary {
  id: string;
  name: string;
  grade: string;
  topicIds: string[];
  suggestedTopicIds: string[];
  topicsAutoAssigned: boolean;
}

interface MigrationSummary {
  status: "running" | "completed" | "failed" | "needs_review";
  classification: "new" | "returning";
  migrationVersion: number;
  tourVersion: number;
  tourCompleted: boolean;
  tourStep: number;
  requiresConfirmation: boolean;
  warnings: string[];
  learners: LearnerSummary[];
}

function requestAction(request: CallableRequest<unknown>): MigrationAction {
  const data = request.data && typeof request.data === "object" ? request.data as MigrationRequest : {};
  const action = data.action ?? "resolve";
  if (!(["resolve", "status", "update-tour", "complete-tour", "apply-registration-events"] as const).includes(action)) {
    throw new HttpsError("invalid-argument", "Unsupported account migration action.");
  }
  return action;
}

function requestPlatform(request: CallableRequest<unknown>): RegistrationPlatform | null {
  const data = request.data && typeof request.data === "object" ? request.data as MigrationRequest : {};
  return data.platform === "web" || data.platform === "ios" || data.platform === "android" ? data.platform : null;
}

const dateKey = (date: Date) => date.toISOString().slice(0, 10);
const monthDay = (value: string) => value.slice(5);
function eventIsActive(event: PremiumPreviewEvent, now = new Date()): boolean {
  if (!event.enabled) return false;
  const current = dateKey(now);
  if (event.recurrence === "one-time") return current >= event.startsOn && current <= event.endsOn;
  const day = monthDay(current); const start = monthDay(event.startsOn); const end = monthDay(event.endsOn);
  return start <= end ? day >= start && day <= end : day >= start || day <= end;
}

function addDays(value: Date, days: number): Date {
  const result = new Date(value);
  result.setUTCDate(result.getUTCDate() + days);
  return result;
}

async function applyPremiumPreview(uid: string, userType: PremiumPreviewUserType, platform: RegistrationPlatform | null): Promise<void> {
  const firestore = getFirestore();
  const eventsSnapshot = await firestore.collection("getgo-events").where("type", "==", "premium-preview").get();
  const eligible = eventsSnapshot.docs
    .map((doc) => ({id: doc.id, ...doc.data()} as PremiumPreviewEvent))
    .filter((event) => {
      const targetPlatforms = event.targets?.platforms;
      const platformMatches = !Array.isArray(targetPlatforms) || targetPlatforms.length === 0
        ? true
        : platform !== null && targetPlatforms.includes(platform);
      return eventIsActive(event) && event.targets?.userTypes?.includes(userType) && platformMatches && Number.isInteger(event.premiumDays) && event.premiumDays > 0;
    })
    .sort((a, b) => b.premiumDays - a.premiumDays);
  if (eligible.length === 0) return;
  const event = eligible[0];
  const migrationRef = firestore.doc(`getgo-account-migrations/${uid}`);
  const parentRef = firestore.doc(`getgo/${uid}`);
  await firestore.runTransaction(async (transaction) => {
    const [migrationSnapshot, parentSnapshot] = await Promise.all([transaction.get(migrationRef), transaction.get(parentRef)]);
    const appliedEventIds = Array.isArray(migrationSnapshot.get("appliedEventIds")) ? migrationSnapshot.get("appliedEventIds") as string[] : [];
    if (appliedEventIds.includes(event.id)) return;
    const now = Timestamp.now();
    const currentExpiry = parentSnapshot.get("subscriptionExpiresAt");
    const currentExpiryDate = currentExpiry instanceof Timestamp ? currentExpiry.toDate() : new Date(0);
    const previewExpiry = addDays(now.toDate(), event.premiumDays);
    const packageId = parentSnapshot.get("packageId");
    if (packageId === "admin" || (packageId === "premium" && currentExpiry == null) || currentExpiryDate >= previewExpiry) {
      transaction.set(migrationRef, {entryReason: userType, appliedEventIds: FieldValue.arrayUnion(event.id), updatedAt: now}, {merge: true});
      return;
    }
    const expiry = Timestamp.fromDate(previewExpiry);
    const entitlement = {packageId: "premium", status: "active", provider: "event", paymentMethod: "premium-preview", eventId: event.id, startsAt: now, expiresAt: expiry, updatedAt: now};
    transaction.set(parentRef, {packageId: "premium", subscriptionStartsAt: now, subscriptionExpiresAt: expiry, subscriptionGrantedAt: now, subscriptionProvider: "event", subscriptionPaymentMethod: "premium-preview", subscriptionEventId: event.id, adfree: true, updatedAt: now}, {merge: true});
    transaction.set(parentRef.collection("subscriptions").doc("family_premium"), entitlement, {merge: true});
    transaction.set(parentRef.collection("entitlements").doc("family_premium"), {...entitlement, entitlement: "family_premium"}, {merge: true});
    transaction.set(parentRef.collection("notifications").doc(`benefit-premium-preview-${event.id}`), {
      schemaVersion: 1,
      kind: "benefit",
      titleKey: "notifications.events.premiumPreviewGrantedTitle",
      messageKey: "notifications.events.premiumPreviewGrantedMessage",
      params: {count: event.premiumDays},
      route: "/parent/subscribe",
      createdAt: now,
      readAt: null,
    });
    transaction.set(migrationRef, {entryReason: userType, appliedEventIds: FieldValue.arrayUnion(event.id), updatedAt: now}, {merge: true});
  });
}

function stringValue(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function stringArray(value: unknown): string[] {
  return Array.isArray(value)
    ? [...new Set(value.map(stringValue).filter(Boolean))]
    : [];
}

function normalized(value: unknown): string {
  return stringValue(value).toLocaleLowerCase().normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();
}

function localizedValues(value: unknown): string[] {
  if (typeof value === "string") return [value];
  if (!value || typeof value !== "object" || Array.isArray(value)) return [];
  return Object.values(value as Record<string, unknown>).map(stringValue).filter(Boolean);
}

function acronym(value: string): string {
  return normalized(value).split(" ").filter(Boolean).map((part) => part[0]).join("");
}

function learnerGradeNumber(value: unknown): number | null {
  const match = stringValue(value).match(/\d+/);
  return match ? Number(match[0]) : null;
}

function topicAccess(value: FirebaseFirestore.DocumentData | undefined): "free" | "subscription" | "paid" {
  const marketplace = value?.marketplace;
  const pricing = marketplace && typeof marketplace === "object" ? marketplace.pricing : value?.pricing;
  const type = pricing && typeof pricing === "object" ? pricing.type : undefined;
  return type === "paid" || type === "subscription" ? type : "free";
}

function matchLegacyTopics(
  legacyTopicIds: string[],
  learnerGrade: string,
  catalog: FirebaseFirestore.QuerySnapshot,
  marketplaceById: Map<string, FirebaseFirestore.DocumentData>,
): {freeTopicIds: string[]; suggestedTopicIds: string[]} {
  const matches = new Set<string>();
  const grade = learnerGradeNumber(learnerGrade);
  for (const legacyId of legacyTopicIds) {
    const legacy = normalized(legacyId);
    if (!legacy) continue;
    let candidates = catalog.docs.filter((topic) => {
      if (normalized(topic.id) === legacy) return true;
      const marketplace = marketplaceById.get(topic.id);
      const names = [
        ...localizedValues(topic.get("title")),
        ...localizedValues(marketplace?.title),
        stringValue(topic.get("contest")),
        stringValue(marketplace?.contest),
      ].filter(Boolean);
      return names.some((name) => {
        const normalizedName = normalized(name);
        return normalizedName === legacy
          || normalizedName.split(" ").includes(legacy)
          || acronym(name) === legacy.split(" ").join("");
      });
    });
    if (grade !== null && candidates.length > 1) {
      const gradeMatches = candidates.filter((topic) => {
        const grades = topic.get("grades");
        return !Array.isArray(grades) || grades.length === 0 || grades.map(Number).includes(grade);
      });
      if (gradeMatches.length > 0) candidates = gradeMatches;
    }
    if (candidates.length === 1) matches.add(candidates[0].id);
  }
  const suggestedTopicIds = [...matches];
  return {
    suggestedTopicIds,
    freeTopicIds: suggestedTopicIds.filter((id) => topicAccess(marketplaceById.get(id)) === "free"),
  };
}

async function liveSummary(uid: string): Promise<{
  classification: "new" | "returning";
  warnings: string[];
  learners: LearnerSummary[];
}> {
  const firestore = getFirestore();
  const parent = firestore.doc(`getgo/${uid}`);
  const [parentSnapshot, learnersSnapshot] = await Promise.all([
    parent.get(),
    parent.collection("students").get(),
  ]);
  const warnings: string[] = [];
  const learners = learnersSnapshot.docs.map((learner) => {
    const data = learner.data();
    const name = stringValue(data.name);
    const grade = stringValue(data.grade);
    const topicIds = stringArray(data.topics);
    const suggestedTopicIds = stringArray(data.migrationSuggestedTopicIds);
    if (!name) warnings.push(`learner:${learner.id}:missing-name`);
    if (!grade) warnings.push(`learner:${learner.id}:missing-grade`);
    if (topicIds.length === 0) warnings.push(`learner:${learner.id}:missing-topics`);
    if (data.parentId && data.parentId !== uid) warnings.push(`learner:${learner.id}:owner-mismatch`);
    return {
      id: learner.id,
      name,
      grade,
      topicIds,
      suggestedTopicIds,
      topicsAutoAssigned: Boolean(data.migrationTopicsAutoAssigned) && topicIds.length > 0,
    };
  });
  return {
    classification: parentSnapshot.exists || learners.length > 0 ? "returning" : "new",
    warnings: [...new Set(warnings)],
    learners,
  };
}

function response(
  record: FirebaseFirestore.DocumentData,
  live: Awaited<ReturnType<typeof liveSummary>>,
): MigrationSummary {
  const status = record.status === "failed" || record.status === "needs_review" || record.status === "running"
    ? record.status
    : "completed";
  return {
    status,
    classification: live.classification,
    migrationVersion: MIGRATION_VERSION,
    tourVersion: TOUR_VERSION,
    tourCompleted: Number(record.welcomeTourVersion ?? 0) >= TOUR_VERSION && Boolean(record.welcomeTourCompletedAt),
    tourStep: Math.max(0, Math.min(2, Number(record.welcomeTourStep ?? 0) || 0)),
    requiresConfirmation: live.warnings.length > 0,
    warnings: live.warnings,
    learners: live.learners,
  };
}

async function resolveAccount(uid: string, platform: RegistrationPlatform | null): Promise<MigrationSummary> {
  const firestore = getFirestore();
  const migration = firestore.doc(`getgo-account-migrations/${uid}`);
  const authUser = await getAuth().getUser(uid);
  const initialMigration = await migration.get();
  if (initialMigration.get("entryReason") !== "new-registration" && Number(initialMigration.get("targetVersion") ?? 0) < MIGRATION_VERSION) {
    await applyPremiumPreview(uid, "legacy-migration", platform);
  }
  const lease = await firestore.runTransaction(async (transaction) => {
    const snapshot = await transaction.get(migration);
    const data = snapshot.data() ?? {};
    if (data.status === "completed" && Number(data.targetVersion) >= MIGRATION_VERSION) return "completed" as const;
    const leaseUntil = data.leaseUntil instanceof Timestamp ? data.leaseUntil.toMillis() : 0;
    if (data.status === "running" && leaseUntil > Date.now()) return "running" as const;
    transaction.set(migration, {
      targetVersion: MIGRATION_VERSION,
      status: "running",
      leaseUntil: Timestamp.fromMillis(Date.now() + LEASE_DURATION_MS),
      startedAt: data.startedAt ?? FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
      attemptCount: FieldValue.increment(1),
    }, {merge: true});
    return "acquired" as const;
  });

  if (lease === "running") {
    const [snapshot, live] = await Promise.all([migration.get(), liveSummary(uid)]);
    return response(snapshot.data() ?? {status: "running"}, live);
  }

  const live = await liveSummary(uid);
  if (lease === "completed") {
    await migration.set({
      classification: live.classification,
      warnings: live.warnings,
      requiresConfirmation: live.warnings.length > 0,
      learnerCount: live.learners.length,
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
    return response((await migration.get()).data() ?? {}, live);
  }

  try {
    const parent = firestore.doc(`getgo/${uid}`);
    const userProfile = firestore.doc(`users/${uid}`);
    const [parentSnapshot, userSnapshot, learnerSnapshots, catalogSnapshot, marketplaceSnapshot] = await Promise.all([
      parent.get(),
      userProfile.get(),
      parent.collection("students").get(),
      firestore.collection("getgo-content-v2/catalog/topics").get(),
      firestore.collection("getgo-marketplace-topics").get(),
    ]);
    const marketplaceById = new Map(marketplaceSnapshot.docs.map((topic) => [topic.id, topic.data()]));
    const now = FieldValue.serverTimestamp();
    const displayName = stringValue(parentSnapshot.get("name"))
      || stringValue(userSnapshot.get("name"))
      || stringValue(authUser.displayName)
      || stringValue(authUser.email?.split("@")[0])
      || "User";
    const email = stringValue(authUser.email) || stringValue(parentSnapshot.get("email"));

    const writer = firestore.bulkWriter();
    if (!userSnapshot.exists) {
      writer.set(userProfile, {
        id: uid,
        name: displayName,
        email,
        status: "active",
        groups: [],
        appRoles: {},
        registeredFrom: "getgo",
        createdAt: now,
        lastLogin: now,
      });
    }
    if (live.classification === "returning") {
      writer.set(parent, {
        id: uid,
        name: displayName,
        email,
        migrationVersion: MIGRATION_VERSION,
        ...(parentSnapshot.exists ? {} : {packageId: "free", createdAt: now}),
        updatedAt: now,
      }, {merge: true});
    }
    for (const learner of learnerSnapshots.docs) {
      const learnerData = learner.data();
      const enabledTopics = stringArray(learnerData.enabledTopics);
      const nativeTopics = stringArray(learnerData.topics);
      const matched = matchLegacyTopics(enabledTopics, stringValue(learnerData.grade), catalogSnapshot, marketplaceById);
      const topics = nativeTopics.length > 0 ? nativeTopics : matched.freeTopicIds;
      writer.set(learner.ref, {
        id: learner.id,
        parentId: uid,
        migrationVersion: MIGRATION_VERSION,
        topics,
        migrationSuggestedTopicIds: matched.suggestedTopicIds,
        migrationTopicsAutoAssigned: nativeTopics.length === 0 && matched.freeTopicIds.length > 0,
        updatedAt: now,
      }, {merge: true});
      for (const topicId of matched.freeTopicIds) {
        writer.set(parent.collection("topics").doc(topicId), {
          topicId,
          parentId: uid,
          access: "free",
          addedAt: now,
          migrationVersion: MIGRATION_VERSION,
        }, {merge: true});
      }
    }
    await writer.close();

    const finalLive = await liveSummary(uid);
    const ownerMismatch = finalLive.warnings.some((warning) => warning.endsWith(":owner-mismatch"));
    const status = ownerMismatch ? "needs_review" : "completed";
    await migration.set({
      sourceVersion: parentSnapshot.get("migrationVersion") ?? "legacy-compatible",
      targetVersion: MIGRATION_VERSION,
      status,
      classification: finalLive.classification,
      warnings: finalLive.warnings,
      requiresConfirmation: finalLive.warnings.length > 0,
      learnerCount: finalLive.learners.length,
      completedAt: status === "completed" ? FieldValue.serverTimestamp() : null,
      leaseUntil: FieldValue.delete(),
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
    logger.info("GetGo account migration resolved", {
      uid,
      status,
      classification: finalLive.classification,
      learnerCount: finalLive.learners.length,
      warningCount: finalLive.warnings.length,
    });
    return response((await migration.get()).data() ?? {status}, finalLive);
  } catch (error) {
    await migration.set({
      status: "failed",
      errorCode: "migration-failed",
      leaseUntil: FieldValue.delete(),
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
    logger.error("GetGo account migration failed", {uid, error});
    throw error;
  }
}

export const resolveGetGoAccountMigration = onCall({
  region: DEPLOYMENT_REGION,
  timeoutSeconds: 120,
  memory: "512MiB",
}, withCallableErrorDetails("Account upgrade could not be completed.", async (request: CallableRequest<unknown>) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Authentication is required.");
  const uid = request.auth.uid;
  const action = requestAction(request);
  const platform = requestPlatform(request);
  const requestData = request.data && typeof request.data === "object" ? request.data as MigrationRequest : {};
  const migration = getFirestore().doc(`getgo-account-migrations/${uid}`);

  if (action === "apply-registration-events") {
    const registrationPlatform = await getFirestore().runTransaction(async (transaction) => {
      const snapshot = await transaction.get(migration);
      const storedPlatform = snapshot.get("entryPlatform");
      const effectivePlatform = storedPlatform === "web" || storedPlatform === "ios" || storedPlatform === "android"
        ? storedPlatform as RegistrationPlatform
        : platform;
      transaction.set(migration, {entryReason: "new-registration", entryPlatform: effectivePlatform, updatedAt: FieldValue.serverTimestamp()}, {merge: true});
      return effectivePlatform;
    });
    await applyPremiumPreview(uid, "new-registration", registrationPlatform);
    const [snapshot, live] = await Promise.all([migration.get(), liveSummary(uid)]);
    return response(snapshot.data() ?? {}, live);
  }

  if (action === "update-tour") {
    const tourStep = Number(requestData.tourStep);
    if (!Number.isInteger(tourStep) || tourStep < 0 || tourStep > 2) {
      throw new HttpsError("invalid-argument", "A valid account upgrade step is required.");
    }
    await migration.set({
      welcomeTourStep: tourStep,
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
  }

  if (action === "complete-tour") {
    const live = await liveSummary(uid);
    if (live.warnings.length > 0) {
      throw new HttpsError("failed-precondition", "Required learner details are incomplete.");
    }
    await migration.set({
      welcomeTourVersion: TOUR_VERSION,
      welcomeTourCompletedAt: FieldValue.serverTimestamp(),
      updatedAt: FieldValue.serverTimestamp(),
    }, {merge: true});
  }

  if (action === "status" || action === "update-tour" || action === "complete-tour") {
    const [snapshot, live] = await Promise.all([migration.get(), liveSummary(uid)]);
    if (!snapshot.exists) return resolveAccount(uid, platform);
    return response(snapshot.data() ?? {}, live);
  }
  return resolveAccount(uid, platform);
}));
