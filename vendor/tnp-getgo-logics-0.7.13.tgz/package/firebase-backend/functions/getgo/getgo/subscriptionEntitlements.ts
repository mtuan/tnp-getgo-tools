import {FieldValue, Timestamp, type DocumentData, type DocumentReference, type QuerySnapshot, type Transaction} from "firebase-admin/firestore";

export type SubscriptionSourceId = "web" | "apple" | "google";
export type SubscriptionSourceRecord = {
  provider: SubscriptionSourceId;
  status: "active" | "expired" | "cancelled";
  productId?: string;
  expiresAt: Timestamp | null;
  autoRenewing: boolean;
  updatedAt?: unknown;
  [key: string]: unknown;
};

const active = (source: SubscriptionSourceRecord, now: number) => source.status === "active"
  && (source.expiresAt === null || source.expiresAt.toMillis() > now);

export const hasActiveRecurringSubscription = (sources: Map<SubscriptionSourceId, SubscriptionSourceRecord>, now = Date.now()) =>
  [...sources.values()].some(source => (source.provider === "apple" || source.provider === "google") && active(source, now));

export function subscriptionSources(snapshot: QuerySnapshot<DocumentData>, legacyParent?: DocumentData): Map<SubscriptionSourceId, SubscriptionSourceRecord> {
  const sources = new Map(snapshot.docs
    .filter(doc => ["web", "apple", "google"].includes(doc.id))
    .map(doc => [doc.id as SubscriptionSourceId, doc.data() as SubscriptionSourceRecord]));
  if (!sources.size && legacyParent?.packageId === "premium") {
    const provider: SubscriptionSourceId = legacyParent.subscriptionProvider === "apple"
      ? "apple" : legacyParent.subscriptionProvider === "google" ? "google" : "web";
    const expiresAt = legacyParent.subscriptionExpiresAt instanceof Timestamp ? legacyParent.subscriptionExpiresAt : null;
    if (expiresAt === null || expiresAt.toMillis() > Date.now()) sources.set(provider, {
      provider, status: "active", productId: legacyParent.subscriptionProductId,
      expiresAt, autoRenewing: provider !== "web",
    });
  }
  return sources;
}

export function applySubscriptionSource(
  tx: Transaction,
  parentRef: DocumentReference,
  existing: Map<SubscriptionSourceId, SubscriptionSourceRecord>,
  sourceId: SubscriptionSourceId,
  source: SubscriptionSourceRecord,
): void {
  const now = Date.now();
  const next = new Map(existing);
  next.set(sourceId, source);
  const activeSources = [...next.values()].filter(item => active(item, now)).sort((left, right) => {
    const leftExpiry = left.expiresAt?.toMillis() ?? Number.MAX_SAFE_INTEGER;
    const rightExpiry = right.expiresAt?.toMillis() ?? Number.MAX_SAFE_INTEGER;
    return rightExpiry - leftExpiry;
  });
  const effective = activeSources[0];
  const billingOwner = activeSources.find(item => item.provider === "apple" || item.provider === "google") ?? effective;
  tx.set(parentRef.collection("subscriptionSources").doc(sourceId), {...source, updatedAt: FieldValue.serverTimestamp()}, {merge: true});
  tx.set(parentRef, effective ? {
    packageId: "premium",
    subscriptionProvider: billingOwner.provider,
    subscriptionProductId: billingOwner.productId ?? FieldValue.delete(),
    subscriptionExpiresAt: effective.expiresAt,
    subscriptionAutoRenewing: billingOwner.autoRenewing,
    subscriptionGrantedAt: FieldValue.serverTimestamp(),
    subscriptionRevokedAt: FieldValue.delete(),
    adfree: true,
  } : {
    packageId: "free",
    subscriptionProvider: FieldValue.delete(),
    subscriptionProductId: FieldValue.delete(),
    subscriptionExpiresAt: Timestamp.now(),
    subscriptionAutoRenewing: false,
    subscriptionRevokedAt: FieldValue.serverTimestamp(),
    adfree: false,
  }, {merge: true});
}
