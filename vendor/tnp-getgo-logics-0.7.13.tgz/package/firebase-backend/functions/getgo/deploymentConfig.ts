/**
 * Typecheck-only default. The deployment assembler replaces this module with
 * the selected target's configured region before Functions compilation.
 */
export const DEPLOYMENT_REGION = "asia-southeast1";
