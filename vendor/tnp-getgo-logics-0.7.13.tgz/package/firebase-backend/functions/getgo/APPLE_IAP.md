# GetGo Apple subscriptions

The billing codebase expects the Secret Manager secret `GETGO_APPLE_IAP_CONFIG`:

```json
{"bundleId":"com.tnpglobal.getgo","appAppleId":6776639420}
```

The `appAppleId` is the numeric Apple ID shown under App Store Connect → App
Information. Configure the secret independently in development, staging, and
production. Do not store an App Store Connect private key in this secret;
signed transaction and notification verification only needs the public Apple
certificate chain, bundle ID, and numeric App Apple ID.

After deploying the billing codebase, configure App Store Connect → App
Information → App Store Server Notifications with the HTTPS URL for
`getGoAppleServerNotifications`. Select Version 2 for both Sandbox and
Production. Use the sandbox URL first and send an App Store Connect test
notification before configuring production.

The client calls `syncGetGoAppleSubscription` after loading, purchasing, or
restoring an active StoreKit entitlement. The callable verifies the Apple JWS
and the deterministic `appAccountToken` before updating the GetGo parent. The
notification endpoint maintains the same entitlement for renewals, expiration,
refunds, and revocations while the app is not running.
