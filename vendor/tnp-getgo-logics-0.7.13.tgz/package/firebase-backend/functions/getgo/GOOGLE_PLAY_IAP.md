# Google Play subscription verification

The billing codebase verifies Android subscription purchase tokens with the Google Play Developer API and stores the verified result as the `google` source under `getgo/{uid}/subscriptionSources/google`.

Required deployment configuration:

1. Set the `GETGO_GOOGLE_PLAY_IAP_CONFIG` secret to JSON containing the production Android application ID, for example `{"packageName":"com.tnp.getgo"}`.
2. Enable the Google Play Android Developer API for the deployment project.
3. Grant the Functions runtime service account access to the app in Google Play Console with permission to view subscription and order data.
4. Create a Google Play real-time developer notifications topic and push subscription targeting the deployed `getGoGooglePlayNotifications` HTTPS function.
5. Configure that topic in Google Play Console.

The client also calls `syncGetGoGooglePlaySubscription` after loading, purchasing, or restoring a subscription. Real-time developer notifications keep renewal, cancellation, grace-period, and expiry state synchronized when the app is not open.
