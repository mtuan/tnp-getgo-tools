/**
 * Firebase Cloud Functions — {TARGET}
 *
 * AUTO-GENERATED — do not edit directly.
 * Edit source files in configs/apps/ and run: npm run deploy:{target}
 */

import {initializeApp} from "firebase-admin/app";
import {getFirestore} from "firebase-admin/firestore";
import {setGlobalOptions} from "firebase-functions/v2";

// Initialize Firebase Admin SDK
initializeApp();
getFirestore().settings({ignoreUndefinedProperties: true});

// Global options for all functions
setGlobalOptions({maxInstances: 10, region: "{FUNCTIONS_REGION}"});
