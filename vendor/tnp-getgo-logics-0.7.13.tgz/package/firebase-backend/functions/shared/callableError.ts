import {
  HttpsError,
  type FunctionsErrorCode,
} from "firebase-functions/v2/https";

const MAX_DEPTH = 4;

function serializeUnknown(value: unknown, depth = 0): unknown {
  if (value === null || value === undefined) return value ?? null;
  if (depth >= MAX_DEPTH) return String(value);
  if (value instanceof Error) {
    const error = value as Error & {
      code?: unknown;
      details?: unknown;
      cause?: unknown;
      customData?: unknown;
    };
    return {
      name: error.name,
      message: error.message,
      stack: error.stack,
      code: serializeUnknown(error.code, depth + 1),
      details: serializeUnknown(error.details, depth + 1),
      customData: serializeUnknown(error.customData, depth + 1),
      cause: serializeUnknown(error.cause, depth + 1),
    };
  }
  if (Array.isArray(value)) {
    return value.map((item) => serializeUnknown(item, depth + 1));
  }
  if (typeof value === "object") {
    return Object.fromEntries(Object.entries(value as Record<string, unknown>)
      .map(([key, item]) => [key, serializeUnknown(item, depth + 1)]));
  }
  return ["string", "number", "boolean"].includes(typeof value) ? value : String(value);
}

export function callableError(
  code: FunctionsErrorCode,
  message: string,
  cause: unknown
): HttpsError {
  return new HttpsError(code, message, {
    cause: serializeUnknown(cause),
    generatedAt: new Date().toISOString(),
  });
}

export function withCallableErrorDetails<TRequest, TResult>(
  fallbackMessage: string,
  handler: (request: TRequest) => Promise<TResult>
): (request: TRequest) => Promise<TResult> {
  return async (request) => {
    try {
      return await handler(request);
    } catch (error) {
      if (error instanceof HttpsError && error.details !== undefined) throw error;
      if (error instanceof HttpsError) {
        throw callableError(error.code, error.message, error);
      }
      throw callableError("internal", fallbackMessage, error);
    }
  };
}
