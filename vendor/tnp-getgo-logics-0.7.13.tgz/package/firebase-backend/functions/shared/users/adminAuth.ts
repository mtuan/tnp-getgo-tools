import {getFirestore} from "firebase-admin/firestore";

const BOOTSTRAP_ADMINS = ["matuan@gmail.com"];

/**
 * Mirrors firestore.rules isAdmin() logic.
 *
 * Admin if caller is:
 * 1) hardcoded bootstrap admin,
 * 2) whitelisted admin (portal-config/whitelist.entries[email].groups), or
 * 3) stored admin in users/{uid}.groups.
 *
 * @param {string} uid Caller UID.
 * @param {string|undefined} email Caller email from auth token.
 * @return {Promise<boolean>} True when caller is authorized as admin.
 */
export async function isAdminUser(
  uid: string,
  email?: string
): Promise<boolean> {
  if (email && BOOTSTRAP_ADMINS.includes(email)) {
    return true;
  }

  const db = getFirestore();

  if (email) {
    const whitelistSnap = await db
      .collection("portal-config")
      .doc("whitelist")
      .get();

    const rawEntries = whitelistSnap.data()?.entries as
      | Record<string, {groups?: string[]}>
      | undefined;
    const entries = rawEntries ?? {};
    const groups = entries[email]?.groups ?? [];

    if (groups.includes("admin")) {
      return true;
    }
  }

  const callerSnap = await db.collection("users").doc(uid).get();
  const callerGroups: string[] = callerSnap.data()?.groups ?? [];
  return callerGroups.includes("admin");
}
