# GetGo Firebase backend sources

This directory owns the canonical Firebase backend contract for GetGo:

- `functions/` contains Cloud Functions sources, shared Function helpers, callable registration, and codebase export metadata.
- `functions-template/` contains the canonical Functions package, lockfile, and TypeScript configuration used for deployable codebases.
- `indexes/` contains application Firestore index declarations.

These files are source inputs, not directly deployable output. GetGo Tools combines them with target-specific region settings, generated Firebase rules, the Web-owned Hosting contract, and vendored dependencies. GetGo Tools owns release orchestration and environment selection.

Environment values and secrets do not belong here. Public runtime values are validated through the browser-safe `@tnp/getgo-logics/runtime-config` entry point, while secret values remain in the target cloud project.
