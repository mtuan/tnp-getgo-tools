# GetGo Firebase backend sources

This directory owns the canonical Firebase backend contract for GetGo:

- `functions/` contains Cloud Functions sources, shared Function helpers, callable registration, and codebase export metadata.
- `indexes/` contains application Firestore index declarations.

These files are source inputs, not directly deployable output. GetGo Web's deployment assembler combines them with target-specific region settings, package templates, generated Firebase rules, and vendored dependencies. GetGo Tools owns release orchestration and environment selection.

Environment values and secrets do not belong here. Public runtime values are validated through the browser-safe `@tnp/getgo-logics/runtime-config` entry point, while secret values remain in the target cloud project.
